export interface StripeEnv {
  STRIPE_SECRET_KEY?: string;
  STRIPE_WEBHOOK_SECRET?: string;
}

type CheckoutPayload = {
  client?: unknown;
  email?: unknown;
  amount?: unknown;
  currency?: unknown;
  reason?: unknown;
  billingMode?: unknown;
  planId?: unknown;
  propertyLimit?: unknown;
};

const jsonHeaders = {
  "content-type": "application/json; charset=utf-8",
  "cache-control": "no-store",
};

function json(data: unknown, status = 200): Response {
  return new Response(JSON.stringify(data), { status, headers: jsonHeaders });
}

function cleanText(value: unknown, maxLength: number): string {
  return typeof value === "string" ? value.trim().slice(0, maxLength) : "";
}

function stripeMode(secret?: string): "production" | "test" | null {
  if (secret?.startsWith("sk_live_") || secret?.startsWith("rk_live_")) return "production";
  if (secret?.startsWith("sk_test_") || secret?.startsWith("rk_test_")) return "test";
  return null;
}

async function inspectStripeConfiguration(env: StripeEnv) {
  const mode = stripeMode(env.STRIPE_SECRET_KEY);
  if (!env.STRIPE_SECRET_KEY || !mode) {
    return { configured: false, verified: false, mode, webhookConfigured: Boolean(env.STRIPE_WEBHOOK_SECRET), accountId: null };
  }
  try {
    const response = await fetch("https://api.stripe.com/v1/account", {
      headers: { authorization: `Bearer ${env.STRIPE_SECRET_KEY}` },
    });
    const account = (await response.json()) as { id?: string };
    return {
      configured: true,
      verified: response.ok && Boolean(account.id),
      mode,
      webhookConfigured: Boolean(env.STRIPE_WEBHOOK_SECRET),
      accountId: response.ok ? account.id ?? null : null,
    };
  } catch {
    return { configured: true, verified: false, mode, webhookConfigured: Boolean(env.STRIPE_WEBHOOK_SECRET), accountId: null };
  }
}

function parseAmount(value: unknown, currency: string): number | null {
  const normalized = String(value ?? "")
    .replace(/\s/g, "")
    .replace(",", ".")
    .replace(/[^0-9.]/g, "");
  const amount = Number(normalized);
  if (!Number.isFinite(amount) || amount <= 0 || amount > 100_000_000) return null;
  return currency === "xof" || currency === "jpy" ? Math.round(amount) : Math.round(amount * 100);
}

function checkoutError(status: number, code: string, message: string): Response {
  return json({ ok: false, code, message }, status);
}

async function createCheckoutSession(request: Request, env: StripeEnv): Promise<Response> {
  const mode = stripeMode(env.STRIPE_SECRET_KEY);
  if (!env.STRIPE_SECRET_KEY || !mode) {
    return checkoutError(503, "stripe_not_configured", "Stripe doit être connecté dans les paramètres sécurisés du site.");
  }

  const originHeader = request.headers.get("origin");
  if (originHeader && originHeader !== new URL(request.url).origin) {
    return checkoutError(403, "origin_not_allowed", "Cette demande de paiement n’est pas autorisée.");
  }

  let payload: CheckoutPayload;
  try {
    payload = (await request.json()) as CheckoutPayload;
  } catch {
    return checkoutError(400, "invalid_json", "La demande de paiement est invalide.");
  }

  const requestedCurrency = cleanText(payload.currency, 8).toUpperCase();
  const currency = requestedCurrency === "FCFA" ? "xof" : requestedCurrency.toLowerCase();
  if (!new Set(["eur", "usd", "gbp", "jpy", "xof"]).has(currency)) {
    return checkoutError(400, "unsupported_currency", "La devise choisie n’est pas prise en charge par Stripe.");
  }

  const unitAmount = parseAmount(payload.amount, currency);
  if (!unitAmount) return checkoutError(400, "invalid_amount", "Saisissez un montant valide.");

  const client = cleanText(payload.client, 120) || "Locataire Nestelya";
  const reason = cleanText(payload.reason, 180) || "Paiement immobilier Nestelya";
  const billingMode = cleanText(payload.billingMode, 20) === "subscription" ? "subscription" : "payment";
  const planId = cleanText(payload.planId, 30);
  const propertyLimit = payload.propertyLimit === null ? "unlimited" : String(payload.propertyLimit ?? "").trim().slice(0, 12);
  if (billingMode === "subscription" && !new Set(["normal", "classique", "excellent"]).has(planId)) {
    return checkoutError(400, "invalid_plan", "La formule d’abonnement est invalide.");
  }
  const email = cleanText(payload.email, 254);
  if (email && !/^\S+@\S+\.\S+$/.test(email)) {
    return checkoutError(400, "invalid_email", "L’adresse e-mail du payeur est invalide.");
  }

  const origin = new URL(request.url).origin;
  const reference = `PM-${Date.now().toString(36).toUpperCase()}-${crypto.randomUUID().slice(0, 8).toUpperCase()}`;
  const form = new URLSearchParams({
    mode: billingMode,
    success_url: `${origin}/?stripe=success&session_id={CHECKOUT_SESSION_ID}`,
    cancel_url: `${origin}/?stripe=cancelled`,
    client_reference_id: reference,
    locale: "fr",
    "line_items[0][price_data][currency]": currency,
    "line_items[0][price_data][unit_amount]": String(unitAmount),
    "line_items[0][price_data][product_data][name]": reason,
    "line_items[0][quantity]": "1",
    "metadata[client]": client,
    "metadata[reason]": reason,
    "metadata[reference]": reference,
    "metadata[billingMode]": billingMode,
    "metadata[planId]": planId,
    "metadata[propertyLimit]": propertyLimit,
  });
  if (billingMode === "subscription") {
    form.set("line_items[0][price_data][recurring][interval]", "month");
    form.set("subscription_data[metadata][client]", client);
    form.set("subscription_data[metadata][reference]", reference);
    form.set("subscription_data[metadata][planId]", planId);
    form.set("subscription_data[metadata][propertyLimit]", propertyLimit);
  } else {
    form.set("payment_intent_data[metadata][client]", client);
    form.set("payment_intent_data[metadata][reason]", reason);
    form.set("payment_intent_data[metadata][reference]", reference);
  }
  if (email) form.set("customer_email", email);

  const idempotencyKey = request.headers.get("idempotency-key") || crypto.randomUUID();
  const stripeResponse = await fetch("https://api.stripe.com/v1/checkout/sessions", {
    method: "POST",
    headers: {
      authorization: `Bearer ${env.STRIPE_SECRET_KEY}`,
      "content-type": "application/x-www-form-urlencoded",
      "idempotency-key": idempotencyKey,
    },
    body: form,
  });
  const stripeData = (await stripeResponse.json()) as {
    id?: string;
    url?: string;
    expires_at?: number;
    error?: { code?: string; message?: string };
  };

  if (!stripeResponse.ok || !stripeData.url || !stripeData.id) {
    return checkoutError(
      502,
      stripeData.error?.code || "stripe_api_error",
      "Stripe n’a pas pu créer la page de paiement. Vérifiez la configuration du compte.",
    );
  }

  return json({
    ok: true,
    id: stripeData.id,
    url: stripeData.url,
    expiresAt: stripeData.expires_at ?? null,
    mode,
    billingMode,
    planId: planId || null,
  });
}

async function retrieveCheckoutSession(request: Request, env: StripeEnv): Promise<Response> {
  const mode = stripeMode(env.STRIPE_SECRET_KEY);
  if (!env.STRIPE_SECRET_KEY || !mode) {
    return checkoutError(503, "stripe_not_configured", "Stripe n’est pas encore connecté.");
  }

  const sessionId = new URL(request.url).searchParams.get("session_id") || "";
  if (!/^cs_(test|live)_[A-Za-z0-9]+$/.test(sessionId)) {
    return checkoutError(400, "invalid_session", "La référence Stripe est invalide.");
  }

  const stripeResponse = await fetch(`https://api.stripe.com/v1/checkout/sessions/${encodeURIComponent(sessionId)}`, {
    headers: { authorization: `Bearer ${env.STRIPE_SECRET_KEY}` },
  });
  const stripeData = (await stripeResponse.json()) as {
    id?: string;
    status?: string;
    payment_status?: string;
    amount_total?: number;
    currency?: string;
    client_reference_id?: string;
    customer_details?: { email?: string | null } | null;
    metadata?: Record<string, string>;
  };
  if (!stripeResponse.ok || !stripeData.id) {
    return checkoutError(404, "session_not_found", "Cette transaction Stripe n’a pas pu être vérifiée.");
  }

  return json({
    ok: true,
    id: stripeData.id,
    status: stripeData.status,
    paymentStatus: stripeData.payment_status,
    paid: stripeData.payment_status === "paid" || stripeData.payment_status === "no_payment_required",
    amountTotal: stripeData.amount_total ?? 0,
    currency: stripeData.currency ?? "eur",
    reference: stripeData.client_reference_id ?? stripeData.metadata?.reference ?? null,
    client: stripeData.metadata?.client ?? "Client Stripe",
    reason: stripeData.metadata?.reason ?? "Paiement immobilier",
    billingMode: stripeData.metadata?.billingMode ?? "payment",
    planId: stripeData.metadata?.planId ?? null,
    propertyLimit: stripeData.metadata?.propertyLimit ?? null,
    customerEmail: stripeData.customer_details?.email ?? null,
    mode,
  });
}

function hex(bytes: ArrayBuffer): string {
  return Array.from(new Uint8Array(bytes), (byte) => byte.toString(16).padStart(2, "0")).join("");
}

function timingSafeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let difference = 0;
  for (let index = 0; index < a.length; index += 1) difference |= a.charCodeAt(index) ^ b.charCodeAt(index);
  return difference === 0;
}

async function verifyWebhookSignature(rawBody: string, signatureHeader: string, secret: string): Promise<boolean> {
  const parts = signatureHeader.split(",").map((part) => part.trim().split("="));
  const timestamp = parts.find(([key]) => key === "t")?.[1];
  const signatures = parts.filter(([key]) => key === "v1").map(([, value]) => value);
  if (!timestamp || signatures.length === 0 || !/^\d+$/.test(timestamp)) return false;
  if (Math.abs(Math.floor(Date.now() / 1000) - Number(timestamp)) > 300) return false;

  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"],
  );
  const digest = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(`${timestamp}.${rawBody}`));
  const expected = hex(digest);
  return signatures.some((signature) => timingSafeEqual(signature, expected));
}

async function receiveWebhook(request: Request, env: StripeEnv): Promise<Response> {
  if (!env.STRIPE_WEBHOOK_SECRET) {
    return checkoutError(503, "webhook_not_configured", "Le secret du webhook Stripe n’est pas configuré.");
  }
  const signature = request.headers.get("stripe-signature") || "";
  const rawBody = await request.text();
  if (!(await verifyWebhookSignature(rawBody, signature, env.STRIPE_WEBHOOK_SECRET))) {
    return checkoutError(400, "invalid_signature", "Signature Stripe invalide.");
  }

  let event: { id?: string; type?: string };
  try {
    event = JSON.parse(rawBody) as { id?: string; type?: string };
  } catch {
    return checkoutError(400, "invalid_event", "Événement Stripe invalide.");
  }
  return json({ received: true, eventId: event.id ?? null, eventType: event.type ?? null });
}

export async function handleStripeRequest(request: Request, env: StripeEnv): Promise<Response | null> {
  const url = new URL(request.url);
  if (url.pathname === "/api/stripe/status" && request.method === "GET") {
    return json(await inspectStripeConfiguration(env));
  }
  if (url.pathname === "/api/stripe/checkout" && request.method === "POST") {
    return createCheckoutSession(request, env);
  }
  if (url.pathname === "/api/stripe/session" && request.method === "GET") {
    return retrieveCheckoutSession(request, env);
  }
  if (url.pathname === "/api/stripe/webhook" && request.method === "POST") {
    return receiveWebhook(request, env);
  }
  return null;
}
