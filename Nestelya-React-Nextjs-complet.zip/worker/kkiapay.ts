export interface KkiapayEnv {
  KKIAPAY_PUBLIC_KEY?: string;
  KKIAPAY_PRIVATE_KEY?: string;
  KKIAPAY_SECRET_KEY?: string;
  KKIAPAY_SANDBOX?: string;
  KKIAPAY_CALLBACK_URL?: string;
  "Public Api Key"?: string;
  "Private Api Key"?: string;
  Secret?: string;
}

type VerifyPayload = {
  transactionId?: unknown;
  billingMode?: unknown;
  planId?: unknown;
  expectedAmount?: unknown;
};

type KkiapayTransaction = {
  transactionId?: unknown;
  transaction_id?: unknown;
  id?: unknown;
  status?: unknown;
  amount?: unknown;
  source?: unknown;
  source_common_name?: unknown;
  performed_at?: unknown;
  reason?: unknown;
};

const subscriptionPrices: Record<string, number> = {
  normal: 5000,
  classique: 10000,
  excellent: 25000,
};

const jsonHeaders = {
  "content-type": "application/json; charset=utf-8",
  "cache-control": "no-store",
};

function json(data: unknown, status = 200): Response {
  return new Response(JSON.stringify(data), { status, headers: jsonHeaders });
}

function clean(value: unknown, maxLength: number): string {
  return typeof value === "string" ? value.trim().slice(0, maxLength) : "";
}

function isSandbox(env: KkiapayEnv): boolean {
  return env.KKIAPAY_SANDBOX?.trim().toLowerCase() === "true";
}

function configuration(env: KkiapayEnv) {
  const publicKey = clean(env.KKIAPAY_PUBLIC_KEY || env["Public Api Key"], 300);
  const privateKey = clean(env.KKIAPAY_PRIVATE_KEY || env["Private Api Key"], 300);
  const secretKey = clean(env.KKIAPAY_SECRET_KEY || env.Secret, 300);
  return {
    publicKey,
    privateKey,
    secretKey,
    widgetConfigured: Boolean(publicKey),
    verificationConfigured: Boolean(publicKey && privateKey && secretKey),
  };
}

function callbackUrl(request: Request, env: KkiapayEnv): string {
  const configured = clean(env.KKIAPAY_CALLBACK_URL, 500);
  if (configured.startsWith("https://")) return configured;
  return "";
}

async function verifyTransaction(request: Request, env: KkiapayEnv): Promise<Response> {
  const config = configuration(env);
  if (!config.verificationConfigured) {
    return json({ ok: false, code: "kkiapay_not_configured", message: "Les clés privées Kkiapay doivent être enregistrées dans les paramètres sécurisés du site." }, 503);
  }

  const originHeader = request.headers.get("origin");
  if (originHeader && originHeader !== new URL(request.url).origin) {
    return json({ ok: false, code: "origin_not_allowed", message: "Cette vérification de paiement n’est pas autorisée." }, 403);
  }

  let payload: VerifyPayload;
  try {
    payload = (await request.json()) as VerifyPayload;
  } catch {
    return json({ ok: false, code: "invalid_json", message: "La demande de vérification est invalide." }, 400);
  }

  const transactionId = clean(payload.transactionId, 120);
  if (!/^[A-Za-z0-9_-]{6,120}$/.test(transactionId)) {
    return json({ ok: false, code: "invalid_transaction", message: "La référence Kkiapay est invalide." }, 400);
  }

  const billingMode = clean(payload.billingMode, 20) === "subscription" ? "subscription" : "payment";
  const planId = clean(payload.planId, 30).toLowerCase();
  if (billingMode === "subscription" && !subscriptionPrices[planId]) {
    return json({ ok: false, code: "invalid_plan", message: "La formule d’abonnement est invalide." }, 400);
  }
  const requestedAmount = Number(payload.expectedAmount);
  const expectedAmount = billingMode === "subscription"
    ? subscriptionPrices[planId]
    : Number.isFinite(requestedAmount) && requestedAmount > 0
      ? Math.round(requestedAmount)
      : null;

  const baseUrl = isSandbox(env) ? "https://api-sandbox.kkiapay.me" : "https://api.kkiapay.me";
  let providerResponse: Response;
  try {
    providerResponse = await fetch(`${baseUrl}/api/v1/transactions/status`, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": config.publicKey,
        "x-private-key": config.privateKey,
        "x-secret-key": config.secretKey,
      },
      body: JSON.stringify({ transactionId }),
    });
  } catch {
    return json({ ok: false, code: "kkiapay_unreachable", message: "Kkiapay n’a pas pu être joint pour confirmer la transaction." }, 502);
  }

  let transaction: KkiapayTransaction = {};
  try {
    transaction = (await providerResponse.json()) as KkiapayTransaction;
  } catch {
    return json({ ok: false, code: "invalid_provider_response", message: "La réponse de vérification Kkiapay est invalide." }, 502);
  }

  if (!providerResponse.ok) {
    return json({ ok: false, code: "kkiapay_verification_failed", message: clean(transaction.reason, 220) || "Kkiapay n’a pas reconnu cette transaction." }, providerResponse.status === 400 || providerResponse.status === 404 ? 404 : 502);
  }

  const providerStatus = clean(transaction.status, 40).toUpperCase();
  const providerAmount = Number(transaction.amount);
  const returnedId = clean(transaction.transactionId ?? transaction.transaction_id ?? transaction.id, 120);
  const transactionMatches = !returnedId || returnedId === transactionId;
  const amountMatches = expectedAmount === null || (Number.isFinite(providerAmount) && Math.round(providerAmount) === expectedAmount);
  const paid = providerStatus === "SUCCESS";
  const verified = paid && transactionMatches && amountMatches;

  return json({
    ok: true,
    verified,
    paid,
    transactionId,
    status: providerStatus || "UNKNOWN",
    amount: Number.isFinite(providerAmount) ? providerAmount : null,
    expectedAmount,
    amountMatches,
    transactionMatches,
    source: clean(transaction.source, 80) || null,
    sourceName: clean(transaction.source_common_name, 120) || null,
    performedAt: clean(transaction.performed_at, 80) || null,
    mode: isSandbox(env) ? "test" : "production",
    billingMode,
    planId: planId || null,
  });
}

export async function handleKkiapayRequest(request: Request, env: KkiapayEnv): Promise<Response | null> {
  const url = new URL(request.url);
  if (url.pathname === "/api/kkiapay/status" && request.method === "GET") {
    const config = configuration(env);
    return json({
      configured: config.widgetConfigured && config.verificationConfigured,
      widgetConfigured: config.widgetConfigured,
      verificationConfigured: config.verificationConfigured,
      mode: isSandbox(env) ? "test" : "production",
      publicKey: config.publicKey || null,
      callbackUrl: callbackUrl(request, env),
    });
  }
  if (url.pathname === "/api/kkiapay/verify" && request.method === "POST") {
    return verifyTransaction(request, env);
  }
  return null;
}
