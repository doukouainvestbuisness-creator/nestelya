import { redirect } from "next/navigation";
import { requireChatGPTUser } from "../chatgpt-auth";
import AdminDashboard from "./admin-dashboard";

export const dynamic = "force-dynamic";

const OWNER_EMAIL = "juniordoukoua@icloud.com";

export default async function AdminPage() {
  const user = await requireChatGPTUser("/admin");
  if (user.email.toLowerCase() !== OWNER_EMAIL) redirect("/");
  return <AdminDashboard ownerName={user.fullName ?? "Junior Doukoua"} ownerEmail={user.email} />;
}
