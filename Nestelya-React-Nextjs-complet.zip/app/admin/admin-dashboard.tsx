"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { LanguageSwitcher } from "../language";

const sections = ["Pilotage", "CRM & clients", "Abonnements", "Paiements", "Support & accès", "Maintenance", "Sécurité"];
const clients = [
  { name:"Awa Immobilier", email:"contact@awaimmo.ci", plan:"Excellent", value:"300 000 FCFA", activity:"Il y a 8 min", status:"Actif" },
  { name:"Marc Kouassi", email:"marc.kouassi@email.com", plan:"Classique", value:"120 000 FCFA", activity:"Il y a 2 h", status:"Actif" },
  { name:"Sarah Martin", email:"sarah.martin@email.com", plan:"Normal", value:"96 €", activity:"Hier à 18:42", status:"Accès bloqué" },
  { name:"Résidences Azur", email:"gestion@residences-azur.ci", plan:"Excellent", value:"300 000 FCFA", activity:"Hier à 09:15", status:"Actif" },
  { name:"Mamadou Diarra", email:"m.diarra@email.com", plan:"Normal", value:"60 000 FCFA", activity:"Il y a 4 jours", status:"En retard" },
];

const adminPlans = [
  {name:"Normal",price:"5 000 FCFA",limit:"Jusqu’à 10 biens",clients:"318",share:"33,6 %",revenue:"1 590 000 FCFA",status:"Actif"},
  {name:"Classique",price:"10 000 FCFA",limit:"De 11 à 20 biens",clients:"402",share:"42,5 %",revenue:"4 020 000 FCFA",status:"Actif"},
  {name:"Excellent",price:"25 000 FCFA",limit:"Biens illimités",clients:"226",share:"23,9 %",revenue:"5 650 000 FCFA",status:"Actif"},
];

export default function AdminDashboard({ownerName,ownerEmail}:{ownerName:string;ownerEmail:string}) {
  const [active,setActive]=useState("Pilotage");
  const [period,setPeriod]=useState("2026");
  const [notice,setNotice]=useState("");
  const [query,setQuery]=useState("");
  const [selected,setSelected]=useState<typeof clients[number]|null>(null);
  const [paymentHealth,setPaymentHealth]=useState({kkiapay:"Vérification…",stripe:"Vérification…"});
  useEffect(()=>{
    Promise.all([
      fetch("/api/kkiapay/status").then(response=>response.json()) as Promise<{configured?:boolean;mode?:string}>,
      fetch("/api/stripe/status").then(response=>response.json()) as Promise<{verified?:boolean;mode?:string;webhookConfigured?:boolean}>,
    ]).then(([kkiapay,stripe])=>setPaymentHealth({
      kkiapay:kkiapay.configured?(kkiapay.mode==="production"?"Production configurée":"Mode test"):"Configuration requise",
      stripe:stripe.verified?(stripe.mode==="production"?(stripe.webhookConfigured?"Production validée":"Webhook requis"):"Mode test"):"Configuration requise",
    })).catch(()=>setPaymentHealth({kkiapay:"Contrôle indisponible",stripe:"Contrôle indisponible"}));
  },[]);
  const notify=(message:string)=>{setNotice(message);window.setTimeout(()=>setNotice(""),3200)};
  const copyPlanLink=async(planName:string)=>{const planId=planName.toLowerCase();const url=new URL(window.location.origin);url.searchParams.set("subscribe",planId);url.searchParams.set("currency","FCFA");url.hash="tarifs";try{await navigator.clipboard.writeText(url.toString());notify(`Lien ${planName} copié · prêt à partager`)}catch{window.prompt("Copiez ce lien de paiement",url.toString())}};
  const filtered=clients.filter(client=>`${client.name} ${client.email} ${client.plan}`.toLowerCase().includes(query.toLowerCase()));

  return <main className="admin-shell">
    {notice&&<div className="admin-toast" role="status">✓ {notice}</div>}
    <aside className="admin-sidebar">
      <Link className="admin-brand" href="/"><span><img className="brand-logo-img" src="/nestelya-logo.png" alt=""/></span><strong>Nestelya</strong></Link>
      <div className="admin-owner-badge"><i>★</i><div><strong>Super Administrateur</strong><small>Accès propriétaire</small></div></div>
      <nav><p>CENTRE DE CONTRÔLE</p>{sections.map((item,index)=><button key={item} className={active===item?"active":""} onClick={()=>setActive(item)}><span>{["⌂","♙","↻","◎","◉","⌁","◇"][index]}</span>{item}{item==="Support & accès"&&<em>7</em>}</button>)}</nav>
      <div className="admin-side-bottom"><Link href="/">← Revenir au site</Link><div><span>JD</span><p><strong>{ownerName}</strong><small>{ownerEmail}</small></p></div></div>
    </aside>

    <section className="admin-content">
      <header className="admin-topbar"><div><p>ADMINISTRATION PROPRIÉTAIRE</p><strong>Centre de contrôle Nestelya</strong></div><LanguageSwitcher compact/><label>Année<select value={period} onChange={e=>setPeriod(e.target.value)}><option>2026</option><option>2025</option><option>2024</option></select></label><button onClick={()=>notify("Rapport administratif préparé")}>⇩ Exporter le rapport</button><span>JD</span></header>
      <div className="admin-main">
        <div className="admin-welcome"><div><p>JEUDI 6 AOÛT {period}</p><h1>Bonjour Junior, voici l’état complet du site.</h1><span>Activité, revenus récurrents, clients et santé technique réunis en un seul espace.</span></div><div><i/> État des services contrôlé en direct</div></div>

        {active==="Pilotage"&&<>
          <div className="admin-kpis">
            <article><span className="green">↗</span><p>Revenus récurrents</p><h2>11 650 €</h2><small>+18,6 % sur un an</small></article>
            <article><span className="blue">♙</span><p>Clients actifs</p><h2>1 284</h2><small>+74 ce mois-ci</small></article>
            <article><span className="amber">↻</span><p>Abonnements actifs</p><h2>946</h2><small>73,7 % de conversion</small></article>
            <article><span className="purple">◎</span><p>Volume encaissé</p><h2>184 260 €</h2><small>2 418 transactions</small></article>
            <article><span className="red">◉</span><p>Tickets ouverts</p><h2>7</h2><small>2 urgents · 5 standards</small></article>
          </div>
          <div className="admin-grid">
            <section className="admin-panel admin-revenue"><div className="admin-panel-title"><div><h3>Évolution annuelle</h3><p>Revenus récurrents et nouveaux clients en {period}</p></div><span>+18,6 % ↗</span></div><div className="admin-chart"><div className="admin-y"><span>12k</span><span>10k</span><span>8k</span><span>6k</span><span>4k</span><span>0</span></div><div className="admin-bars">{[54,59,61,66,69,72,76,81,86,91,95,100].map((height,index)=><div key={index}><i style={{height:`${height}%`}}/><span>{["Jan","Fév","Mar","Avr","Mai","Juin","Juil","Août","Sep","Oct","Nov","Déc"][index]}</span></div>)}</div></div><div className="admin-chart-foot"><span><i/> Revenu mensuel récurrent</span><strong>Prévision fin d’année : 139 800 €</strong></div></section>
            <section className="admin-panel"><div className="admin-panel-title"><div><h3>Ce qui fonctionne</h3><p>Performance par module</p></div><button onClick={()=>notify("Analyse détaillée ouverte")}>Détails →</button></div><div className="module-performance">{[["Paiements & relances","96 %","+22 %"],["Gestion des biens","91 %","+17 %"],["Réservations Airbnb","87 %","+14 %"],["Maintenance","82 %","+9 %"],["Documents","76 %","+6 %"]].map(row=><article key={row[0]}><div><strong>{row[0]}</strong><small>{row[2]}</small></div><span><i style={{width:row[1]}}/></span><b>{row[1]}</b></article>)}</div></section>
          </div>
          <div className="admin-grid lower">
            <section className="admin-panel"><div className="admin-panel-title"><div><h3>Répartition des abonnements</h3><p>946 abonnements actifs</p></div><button onClick={()=>setActive("Abonnements")}>Gérer →</button></div><div className="plan-list"><div className="plan-donut"><span><strong>946</strong><small>actifs</small></span></div><div>{[["Normal","318","33,6 %"],["Classique","402","42,5 %"],["Excellent","226","23,9 %"]].map(x=><p key={x[0]}><i/><span>{x[0]}</span><strong>{x[1]}</strong><small>{x[2]}</small></p>)}</div></div></section>
            <section className="admin-panel"><div className="admin-panel-title"><div><h3>Santé de la plateforme</h3><p>Surveillance des services critiques</p></div><span className="health">TEMPS RÉEL</span></div><div className="health-list">{[["Application web","Opérationnel"],["Base de données","Opérationnel"],["Paiements Kkiapay",paymentHealth.kkiapay],["Stripe Checkout",paymentHealth.stripe],["WhatsApp Business","Connexion requise"],["Sauvegarde automatique","Opérationnel"]].map(x=><p key={x[0]}><i className={x[1]==="Opérationnel"||x[1]==="Production validée"||x[1]==="Production configurée"?"ok":"warn"}/><strong>{x[0]}</strong><span>{x[1]}</span></p>)}</div></section>
          </div>
        </>}

        {active!=="Pilotage"&&<>
          <div className="admin-section-head"><div><h1>{active}</h1><p>{active==="CRM & clients"?"Suivez chaque client, son engagement, ses paiements et ses demandes.":active==="Support & accès"?"Résolvez les problèmes de connexion et sécurisez les comptes clients.":`Pilotez la section ${active.toLowerCase()} depuis votre espace propriétaire.`}</p></div><button onClick={()=>notify(active==="CRM & clients"?"Fiche de création client ouverte":active==="Maintenance"?"Diagnostic complet lancé":"Nouvelle action créée")}>＋ Nouvelle action</button></div>
          {(active==="CRM & clients"||active==="Support & accès")&&<section className="admin-panel clients-panel"><div className="client-tools"><label>⌕<input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Rechercher un client, un e-mail ou un abonnement…"/></label><select><option>Tous les statuts</option><option>Actif</option><option>Accès bloqué</option><option>En retard</option></select><button onClick={()=>notify("Liste des clients exportée")}>⇩ Exporter</button></div><div className="admin-table"><div className="admin-table-row head"><span>CLIENT</span><span>ABONNEMENT</span><span>VALEUR ANNUELLE</span><span>DERNIÈRE ACTIVITÉ</span><span>STATUT</span><span>ACTIONS</span></div>{filtered.map(client=><div className="admin-table-row" key={client.email}><span className="admin-client"><i>{client.name.split(" ").map(x=>x[0]).join("").slice(0,2)}</i><span><strong>{client.name}</strong><small>{client.email}</small></span></span><span><b className={`plan ${client.plan.toLowerCase()}`}>{client.plan}</b></span><span><strong>{client.value}</strong></span><span>{client.activity}</span><span><b className={`client-status ${client.status.toLowerCase().replace(" ","-")}`}>● {client.status}</b></span><span><button onClick={()=>setSelected(client)}>Gérer</button></span></div>)}</div></section>}
          {active==="Abonnements"&&<><div className="admin-subscription-kpis"><article><span>946</span><p>Abonnements actifs</p><small>+74 ce mois-ci</small></article><article><span>11 260 000 FCFA</span><p>Revenu mensuel récurrent</p><small>+18,6 % sur un an</small></article><article><span>73,7 %</span><p>Taux de conversion</p><small>Essai vers abonnement</small></article><article><span>2,1 %</span><p>Taux de résiliation</p><small>-0,4 point ce mois</small></article></div><div className="admin-plan-grid">{adminPlans.map(plan=><article key={plan.name}><div className="admin-plan-head"><span>{plan.name.charAt(0)}</span><div><h2>{plan.name}</h2><p>{plan.limit}</p></div><em>{plan.status}</em></div><strong className="admin-plan-price">{plan.price}<small>/ mois</small></strong><div className="admin-plan-stats"><p><span>Clients actifs</span><strong>{plan.clients}</strong></p><p><span>Répartition</span><strong>{plan.share}</strong></p><p><span>Revenu mensuel</span><strong>{plan.revenue}</strong></p></div><div className="admin-plan-actions"><button onClick={()=>notify(`Tarif ${plan.name} ouvert pour modification`)}>Modifier la formule</button><button onClick={()=>copyPlanLink(plan.name)}>⌁ Copier le lien</button></div></article>)}</div><section className="admin-panel admin-currency-panel"><div><span>€ $ £ ¥</span><p><strong>Tarification internationale activée</strong><small>EUR, USD, GBP et JPY sont encaissés via Stripe. Le FCFA est encaissé via Kkiapay.</small></p></div><button onClick={()=>notify("Paramètres des devises ouverts")}>Gérer les devises →</button></section></>}
          {active!=="CRM & clients"&&active!=="Support & accès"&&active!=="Abonnements"&&<div className="admin-service-grid">{["Vue générale","Activité récente","Paramètres","Alertes et anomalies","Historique annuel","Rapports"].map((item,index)=><article key={item}><span>{["↗","◷","⚙","!","↻","▤"][index]}</span><h3>{item}</h3><p>Consultez et gérez les informations de {active.toLowerCase()} depuis ce panneau.</p><button onClick={()=>notify(`${item} ouvert`)}>Ouvrir →</button></article>)}</div>}
        </>}
      </div>
    </section>

    {selected&&<div className="admin-modal-backdrop" onMouseDown={()=>setSelected(null)}><section className="admin-account-modal" role="dialog" aria-modal="true" onMouseDown={e=>e.stopPropagation()}><button className="admin-modal-close" onClick={()=>setSelected(null)}>×</button><div className="account-head"><i>{selected.name.split(" ").map(x=>x[0]).join("").slice(0,2)}</i><div><h2>{selected.name}</h2><p>{selected.email}</p></div><span>{selected.status}</span></div><div className="account-info"><p><span>Abonnement</span><strong>{selected.plan}</strong></p><p><span>Valeur annuelle</span><strong>{selected.value}</strong></p><p><span>Dernière activité</span><strong>{selected.activity}</strong></p><p><span>Sécurité</span><strong>2FA recommandée</strong></p></div><h3>Assistance et accès</h3><div className="account-actions"><button onClick={()=>notify(`Lien de réinitialisation envoyé à ${selected.email}`)}><span>✉</span><strong>Réinitialiser le mot de passe</strong><small>Envoyer un lien sécurisé par e-mail</small></button><button onClick={()=>notify(`Toutes les sessions de ${selected.name} ont été fermées`)}><span>◇</span><strong>Fermer toutes les sessions</strong><small>Déconnecter le compte sur tous les appareils</small></button><button onClick={()=>notify(`Accès de ${selected.name} réactivé`)}><span>✓</span><strong>Rétablir l’accès au compte</strong><small>Débloquer et renvoyer les instructions</small></button><button className="danger" onClick={()=>notify(`Compte de ${selected.name} suspendu avec journalisation`)}><span>!</span><strong>Suspendre le compte</strong><small>Bloquer temporairement toute connexion</small></button></div><div className="audit-note">◇ Toutes les actions administrateur sont enregistrées dans le journal d’audit.</div></section></div>}
  </main>;
}
