"use client";

import { useEffect, useRef, useState, type FormEvent } from "react";
import { DocumentsModule, FinancesModule, MaintenanceModule, PropertiesModule, ReservationsModule, TenantsModule } from "./modules";
import { LanguageSwitcher } from "./language";

type KkiapayResponse = { transactionId?: string };

declare global {
  interface Window {
    openKkiapayWidget?: (options: Record<string, unknown>) => void;
    addSuccessListener?: (callback: (response: KkiapayResponse) => void) => void;
    addFailedListener?: (callback: () => void) => void;
    addKkiapayListener?: (event: "success" | "failed", callback: (response: KkiapayResponse) => void) => void;
    removeKkiapayListener?: (event: "success" | "failed") => void;
  }
}

const nav = ["Vue d’ensemble", "Mes biens", "Locataires", "Réservations", "Finances", "Paiements", "Abonnement", "Automatisations", "Maintenance", "Documents"];

type PlanId = "normal" | "classique" | "excellent";
type CurrencyCode = "FCFA" | "EUR" | "USD" | "GBP" | "JPY";

type SubscriptionPlan = {
  id: PlanId;
  name: string;
  subtitle: string;
  propertyLimit: number | null;
  prices: Record<CurrencyCode, number>;
  features: string[];
  featured?: boolean;
};

const CURRENCIES: Array<{ code: CurrencyCode; label: string }> = [
  { code: "FCFA", label: "FCFA" },
  { code: "EUR", label: "€" },
  { code: "USD", label: "$" },
  { code: "GBP", label: "£" },
  { code: "JPY", label: "¥" },
];

const SUBSCRIPTION_PLANS: SubscriptionPlan[] = [
  {
    id: "normal",
    name: "Normal",
    subtitle: "Pour démarrer sereinement",
    propertyLimit: 10,
    prices: { FCFA: 5000, EUR: 8, USD: 9, GBP: 7, JPY: 1300 },
    features: ["Jusqu’à 10 biens", "Gestion des loyers et locataires", "Liens de paiement", "Rappels WhatsApp et e-mail"],
  },
  {
    id: "classique",
    name: "Classique",
    subtitle: "Pour un patrimoine en croissance",
    propertyLimit: 20,
    prices: { FCFA: 10000, EUR: 16, USD: 18, GBP: 14, JPY: 2600 },
    features: ["De 11 à 20 biens", "Toutes les fonctions Normal", "États des lieux numériques", "Rapports financiers avancés"],
    featured: true,
  },
  {
    id: "excellent",
    name: "Excellent",
    subtitle: "Pour gérer sans aucune limite",
    propertyLimit: null,
    prices: { FCFA: 25000, EUR: 39, USD: 45, GBP: 34, JPY: 6500 },
    features: ["Nombre de biens illimité", "Toutes les fonctions Classique", "Automatisations prioritaires", "Assistance premium"],
  },
];

const isPlanId = (value: string | null): value is PlanId => SUBSCRIPTION_PLANS.some((plan) => plan.id === value);
const isCurrencyCode = (value: string | null): value is CurrencyCode => CURRENCIES.some((currency) => currency.code === value);
const getPlan = (planId: PlanId) => SUBSCRIPTION_PLANS.find((plan) => plan.id === planId) ?? SUBSCRIPTION_PLANS[0];
const formatPlanPrice = (plan: SubscriptionPlan, currency: CurrencyCode) => {
  const value = plan.prices[currency].toLocaleString("fr-FR");
  const symbol = CURRENCIES.find((item) => item.code === currency)?.label ?? currency;
  return currency === "FCFA" ? `${value} FCFA` : `${symbol}${value}`;
};

const cleanSharedText = (value: string | null, fallback: string, maxLength: number) => {
  const cleaned = (value ?? "").replace(/[\u0000-\u001f\u007f]/g, " ").trim().slice(0, maxLength);
  return cleaned || fallback;
};

const parseSharedAmount = (value: string | null) => {
  const normalized = (value ?? "").replace(/\s/g, "").replace(",", ".").replace(/[^0-9.]/g, "");
  const amount = Number(normalized);
  return Number.isFinite(amount) && amount > 0 && amount <= 100_000_000 ? String(amount) : null;
};

type PaymentTransaction = {
  client: string;
  ref: string;
  property: string;
  method: string;
  amount: string;
  date: string;
  status: string;
};

type StripeStatus = {
  configured: boolean;
  verified: boolean;
  mode: "production" | "test" | null;
  webhookConfigured: boolean;
};

type KkiapayStatus = {
  configured: boolean;
  widgetConfigured: boolean;
  verificationConfigured: boolean;
  mode: "production" | "test";
  publicKey: string | null;
  callbackUrl: string;
};

type PaymentDetails = {
  client: string;
  email: string;
  amount: string;
  currency: CurrencyCode;
  reason: string;
  billingMode: "payment" | "subscription";
  planId: PlanId | "";
  propertyLimit: number | null;
};

const initialTransactions: PaymentTransaction[] = [
  { client: "Aminata Koné", ref: "LOY-2026-0841", property: "Villa Riviera", method: "Kkiapay", amount: "485 000 FCFA", date: "06 août · 10:42", status: "Payé" },
  { client: "Sarah Martin", ref: "AIR-2026-0838", property: "Loft Sablon", method: "Stripe", amount: "420 €", date: "06 août · 09:18", status: "Payé" },
  { client: "Marc Kouassi", ref: "LOY-2026-0832", property: "Appt. Plateau", method: "Chariow", amount: "1 250 €", date: "05 août · 17:05", status: "En attente" },
  { client: "Fatou Diarra", ref: "LOY-2026-0826", property: "Résidence Azur", method: "Kkiapay", amount: "350 000 FCFA", date: "04 août · 14:21", status: "Payé" },
];

const initialProperties = [
  { id: "villa-riviera", name: "Villa Riviera", place: "Abidjan · Cocody", type: "Villa", value: "1 850 €", meta: "Loyer mensuel", state: "Occupé", tone: "green", art: "villa" },
  { id: "loft-sablon", name: "Loft Sablon", place: "Bruxelles · Sablon", type: "Airbnb", value: "92 %", meta: "Taux d’occupation", state: "Réservé", tone: "blue", art: "loft" },
  { id: "residence-azur", name: "Résidence Azur", place: "Grand-Bassam", type: "Appartement", value: "640 €", meta: "Loyer mensuel", state: "Disponible", tone: "amber", art: "azure" },
];

const PROPERTY_IMAGES: Record<string, string> = {
  villa: "/patrimo-villa.webp",
  maison: "/patrimo-maison.webp",
  loft: "/patrimo-appartement.webp",
  azure: "/patrimo-appartement.webp",
  building: "/patrimo-modern-building.png",
};

const getPropertyImage = (property: { art?: string; type?: string }) => {
  if (property.art && PROPERTY_IMAGES[property.art]) return PROPERTY_IMAGES[property.art];
  const type = property.type?.toLowerCase() ?? "";
  if (type.includes("villa")) return PROPERTY_IMAGES.villa;
  if (type.includes("maison")) return PROPERTY_IMAGES.maison;
  if (type.includes("appartement") || type.includes("airbnb")) return PROPERTY_IMAGES.azure;
  return PROPERTY_IMAGES.building;
};

function LandingPage({onEnter,onViewSubscriptions}:{onEnter:(section?:string)=>void;onViewSubscriptions:()=>void}) {
  const [authMode,setAuthMode]=useState<"login"|"signup"|null>(null);
  const [authMessage,setAuthMessage]=useState("");
  const [contactSent,setContactSent]=useState(false);
  const submitAuth=(event:FormEvent<HTMLFormElement>)=>{event.preventDefault();const data=new FormData(event.currentTarget);if(authMode==="signup") window.localStorage.setItem("patrimo-account",JSON.stringify({name:data.get("name"),email:data.get("email"),whatsapp:data.get("whatsapp"),country:data.get("country"),profile:data.get("profile")}));setAuthMode(null);setAuthMessage("");onEnter("Vue d’ensemble");};
  const requestPasswordReset=(form:HTMLFormElement|null)=>{if(!form)return;const data=new FormData(form);const email=String(data.get("email")||"").trim();if(!email){setAuthMessage("Saisissez d’abord votre adresse e-mail.");return;}window.localStorage.setItem("patrimo-password-reset",JSON.stringify({email,requestedAt:new Date().toISOString()}));setAuthMessage(`Un lien de réinitialisation a été préparé pour ${email}.`);};
  const submitContact=(event:FormEvent<HTMLFormElement>)=>{event.preventDefault();const data=Object.fromEntries(new FormData(event.currentTarget));window.localStorage.setItem("patrimo-contact-request",JSON.stringify({...data,date:new Date().toISOString()}));setContactSent(true);const subject=encodeURIComponent(`Nestelya — ${String(data.subject)}`);const body=encodeURIComponent(`Nom : ${String(data.name)}\nE-mail : ${String(data.email)}\nWhatsApp : ${String(data.whatsapp||"Non renseigné")}\n\n${String(data.message)}`);window.location.href=`mailto:juniordoukoua@icloud.com?subject=${subject}&body=${body}`;event.currentTarget.reset();};
  return <main className="landing-page">
    <header className="landing-nav">
      <a className="landing-brand" href="#accueil" aria-label="Nestelya, accueil"><span><img className="brand-logo-img" src="/nestelya-logo.png" alt=""/></span><strong>Nestelya</strong></a>
      <nav aria-label="Navigation principale"><a href="#solutions">Solutions</a><a href="#fonctionnalites">Fonctionnalités</a><button type="button" className="landing-tariffs-link" onClick={onViewSubscriptions}>Tarifs</button><a href="#securite">Sécurité</a><a href="#contact">Contact</a></nav>
      <div className="landing-nav-actions"><LanguageSwitcher/><button className="landing-login" onClick={()=>setAuthMode("login")}>Connexion</button><button className="landing-nav-cta" onClick={()=>setAuthMode("signup")}>Créer un compte <span>→</span></button></div>
    </header>

    <section className="landing-hero" id="accueil">
      <img src="/patrimo-modern-building.png" alt="Immeuble résidentiel contemporain avec façades vitrées et balcons végétalisés"/>
      <div className="landing-hero-shade"/>
      <div className="landing-hero-content">
        <span className="landing-badge"><i>✦</i> Nestelya · La gestion immobilière réinventée par l’IA</span>
        <h1>Votre patrimoine.<br/><em>Géré sans stress.</em></h1>
        <p>Loyers, réservations, locataires, maintenance et paiements : Nestelya automatise tout, pendant que vous profitez de l’essentiel.</p>
        <div className="landing-hero-actions"><button onClick={()=>onEnter("Vue d’ensemble")}>Découvrir mon tableau de bord <span>→</span></button><a href="#solutions"><i>▶</i> Voir comment ça fonctionne</a></div>
        <div className="landing-trust"><span><b>✓</b> Sans installation</span><span><b>✓</b> Accessible partout</span><span><b>✓</b> Paiements sécurisés</span></div>
      </div>
      <div className="hero-performance-card">
        <div className="hero-card-head"><span>Performance du mois</span><i>↗ 8,4 %</i></div>
        <strong>12 480 €</strong><small>Revenus encaissés</small>
        <div className="hero-mini-chart">{[28,42,35,59,50,73,67,88,80,100].map((h,i)=><i key={i} style={{height:`${h}%`}}/>)}</div>
        <div className="hero-card-foot"><span><i/> 94 % occupés</span><b>Tout est sous contrôle</b></div>
      </div>
    </section>

    <section className="landing-audience"><p>UNE PLATEFORME PENSÉE POUR</p><div><span>⌂ Propriétaires</span><span>◫ Agences immobilières</span><span>◇ Locations Airbnb</span><span>▦ Gestionnaires de patrimoine</span><span>⌁ Syndics</span></div></section>

    <section className="landing-solutions" id="solutions">
      <div className="landing-section-title"><span>TOUT-EN-UN</span><h2>Un seul espace pour tout gérer.</h2><p>Centralisez votre patrimoine et automatisez chaque tâche, depuis votre téléphone ou votre ordinateur.</p></div>
      <div className="landing-feature-grid" id="fonctionnalites">
        <article><span className="feature-icon purple">⌂</span><small>PATRIMOINE</small><h3>Tous vos biens, en un coup d’œil</h3><p>Maisons, appartements, immeubles ou Airbnb : suivez l’occupation, la valeur et la rentabilité de chaque bien.</p><button onClick={()=>onEnter("Mes biens")}>Gérer mes biens <b>→</b></button></article>
        <article><span className="feature-icon green">◎</span><small>PAIEMENTS</small><h3>Encaissez simplement, partout</h3><p>Kkiapay, Stripe, Mobile Money et cartes bancaires réunis pour des paiements fluides et des quittances automatiques.</p><button onClick={()=>onEnter("Paiements")}>Voir les paiements <b>→</b></button></article>
        <article><span className="feature-icon amber">⚡</span><small>AUTOMATISATION</small><h3>WhatsApp travaille pour vous</h3><p>Confirmations, rappels de loyer, relances et liens de paiement sont envoyés automatiquement au bon moment.</p><button onClick={()=>onEnter("Automatisations")}>Découvrir l’automatisation <b>→</b></button></article>
      </div>
    </section>

    <section className="landing-dark" id="securite">
      <div className="landing-dark-copy"><span>✦ INTELLIGENCE IMMOBILIÈRE</span><h2>Anticipez avant même<br/>que les problèmes arrivent.</h2><p>L’intelligence artificielle détecte les impayés, les dépenses inhabituelles et les maintenances à prévoir. Vous êtes alerté, Nestelya prépare l’action.</p><ul><li><i>✓</i><div><strong>Risques détectés automatiquement</strong><small>Scores locataires et anomalies financières</small></div></li><li><i>✓</i><div><strong>Interventions mieux organisées</strong><small>Priorité, technicien et suivi centralisé</small></div></li><li><i>✓</i><div><strong>Vos données restent protégées</strong><small>Chiffrement, sauvegardes et journal d’audit</small></div></li></ul><button onClick={()=>onEnter("Vue d’ensemble")}>Entrer dans Nestelya <span>→</span></button></div>
      <div className="landing-dark-visual"><div className="ai-orbit"><span>IA</span><i/><i/><i/></div><article className="ai-card ai-alert"><span>!</span><div><small>ALERTE INTELLIGENTE</small><strong>Risque d’impayé détecté</strong><p>Relance WhatsApp programmée</p></div></article><article className="ai-card ai-maint"><span>⌁</span><div><small>MAINTENANCE</small><strong>Climatisation à contrôler</strong><p>Échéance dans 8 jours</p></div></article><article className="ai-card ai-value"><span>↗</span><div><small>VALEUR DU PATRIMOINE</small><strong>+ 4,8 % cette année</strong><p>Prévision actualisée</p></div></article></div>
    </section>

    <section className="landing-contact" id="contact"><div className="contact-intro"><span>CONTACT & ASSISTANCE</span><h2>Parlons de votre patrimoine.</h2><p>Une question sur Nestelya ou besoin d’un accompagnement ? Envoyez-nous un message ou échangez directement sur WhatsApp.</p><div className="contact-channel"><i>◉</i><div><strong>Assistance WhatsApp</strong><small>Échange rapide depuis votre téléphone</small></div><a href="https://wa.me/?text=Bonjour%20Nestelya%2C%20je%20souhaite%20obtenir%20des%20informations." target="_blank" rel="noreferrer">Ouvrir WhatsApp →</a></div><div className="contact-channel"><i>✉</i><div><strong>Assistance par e-mail</strong><small>Réponse personnalisée à votre demande</small></div><a href="mailto:juniordoukoua@icloud.com">Écrire un e-mail →</a></div></div><form className="landing-contact-form" onSubmit={submitContact}><div className="contact-form-head"><strong>Envoyez-nous un message</strong><small>Nous vous répondrons par e-mail ou WhatsApp.</small></div><div className="contact-form-grid"><label>Nom complet *<input name="name" placeholder="Votre nom" required/></label><label>Adresse e-mail *<input name="email" type="email" placeholder="vous@email.com" required/></label></div><div className="contact-form-grid"><label>Numéro WhatsApp<input name="whatsapp" type="tel" placeholder="+225… ou +32…"/></label><label>Sujet<select name="subject"><option>Découvrir Nestelya</option><option>Créer mon compte</option><option>Paiements et Mobile Money</option><option>Assistance technique</option><option>Autre demande</option></select></label></div><label>Votre message *<textarea name="message" rows={5} placeholder="Expliquez-nous votre besoin…" required/></label><button type="submit">Envoyer ma demande <span>→</span></button>{contactSent&&<p className="contact-success" role="status">✓ Votre demande a bien été préparée dans votre messagerie.</p>}</form></section>

    <section className="landing-final-cta"><span className="landing-badge"><i>✦</i> Votre patrimoine mérite mieux</span><h2>Pilotez tout. Sans vous compliquer la vie.</h2><p>Rejoignez une nouvelle façon de gérer l’immobilier : plus simple, plus intelligente et toujours accessible.</p><button onClick={()=>setAuthMode("signup")}>Créer mon compte gratuitement <span>→</span></button></section>
    <footer className="landing-footer"><a className="landing-brand" href="#accueil"><span><img className="brand-logo-img" src="/nestelya-logo.png" alt=""/></span><strong>Nestelya</strong></a><p>Votre patrimoine, simplement.</p><div><a href="#solutions">Solutions</a><button type="button" onClick={onViewSubscriptions}>Tarifs</button><a href="#securite">Sécurité</a><a href="#contact">Contact</a><button onClick={()=>setAuthMode("login")}>Connexion</button></div><small>© 2026 Nestelya. Tous droits réservés.</small></footer>
    {authMode&&<div className="landing-auth-backdrop" role="presentation" onMouseDown={()=>setAuthMode(null)}><section className="landing-auth-modal" role="dialog" aria-modal="true" aria-label={authMode==="login"?"Connexion":"Création de compte"} onMouseDown={e=>e.stopPropagation()}><button className="auth-close" aria-label="Fermer" onClick={()=>setAuthMode(null)}>×</button><a className="landing-brand auth-brand" href="#accueil"><span><img className="brand-logo-img" src="/nestelya-logo.png" alt=""/></span><strong>Nestelya</strong></a><div className="auth-tabs"><button className={authMode==="login"?"active":""} onClick={()=>{setAuthMode("login");setAuthMessage("")}}>Connexion</button><button className={authMode==="signup"?"active":""} onClick={()=>{setAuthMode("signup");setAuthMessage("")}}>Créer un compte</button></div>{authMode==="login"?<><div className="auth-title"><h2>Ravi de vous revoir.</h2><p>Connectez-vous pour accéder à votre patrimoine.</p></div><form className="auth-form" onSubmit={submitAuth} onChange={()=>setAuthMessage("")}><label>Adresse e-mail<input name="email" type="email" placeholder="vous@email.com" required autoFocus/></label><label>Mot de passe<input name="password" type="password" placeholder="Votre mot de passe" required/></label><div className="auth-options"><label><input type="checkbox"/> Se souvenir de moi</label><button type="button" onClick={(event)=>requestPasswordReset(event.currentTarget.closest("form") as HTMLFormElement)}>Mot de passe oublié ?</button></div>{authMessage&&<p className="auth-feedback" role="status">{authMessage}</p>}<button type="submit">Se connecter <span>→</span></button></form></>:<><div className="auth-title"><h2>Créez votre espace.</h2><p>Commencez à gérer votre patrimoine plus simplement.</p></div><form className="auth-form" onSubmit={submitAuth}><div className="auth-form-grid"><label>Nom complet<input name="name" placeholder="Votre nom" required autoFocus/></label><label>Profil<select name="profile"><option>Propriétaire</option><option>Agence immobilière</option><option>Gestionnaire</option><option>Syndic</option><option>Investisseur</option></select></label></div><label>Adresse e-mail<input name="email" type="email" placeholder="vous@email.com" required/></label><div className="auth-form-grid"><label>Numéro WhatsApp<input name="whatsapp" type="tel" placeholder="+225…" required/></label><label>Pays<select name="country"><option>Côte d’Ivoire</option><option>Belgique</option><option>France</option><option>Italie</option><option>Sénégal</option><option>Autre</option></select></label></div><label>Créer un mot de passe<input name="password" type="password" minLength={8} placeholder="8 caractères minimum" required/></label><label className="auth-consent"><input type="checkbox" required/> J’accepte les conditions d’utilisation et la politique de confidentialité.</label><button type="submit">Créer mon compte <span>→</span></button></form></>}<div className="auth-secure">⌾ Connexion sécurisée · Données chiffrées</div></section></div>}
  </main>;
}

export default function Home() {
  const [showDashboard, setShowDashboard] = useState(false);
  const [active, setActive] = useState("Vue d’ensemble");
  const [notice, setNotice] = useState("");
  const [menu, setMenu] = useState(false);
  const [paymentModal, setPaymentModal] = useState(false);
  const [propertyModal, setPropertyModal] = useState(false);
  const [paymentTab, setPaymentTab] = useState("Transactions");
  const [provider, setProvider] = useState("Kkiapay");
  const [kkiapayReady, setKkiapayReady] = useState(false);
  const [stripeLoading, setStripeLoading] = useState(false);
  const [stripeStatus, setStripeStatus] = useState<StripeStatus>({ configured: false, verified: false, mode: null, webhookConfigured: false });
  const [kkiapayStatus, setKkiapayStatus] = useState<KkiapayStatus>({ configured: false, widgetConfigured: false, verificationConfigured: false, mode: "production", publicKey: null, callbackUrl: "" });
  const [paymentTransactions, setPaymentTransactions] = useState<PaymentTransaction[]>(initialTransactions);
  const [paymentDetails, setPaymentDetails] = useState<PaymentDetails>({ client: "Marc Kouassi", email: "", amount: "4000", currency: "FCFA", reason: "Loyer août 2026 · Appt. Plateau", billingMode: "payment", planId: "", propertyLimit: null });
  const [kkiapayPhone, setKkiapayPhone] = useState("97000000");
  const [propertyList, setPropertyList] = useState(initialProperties);
  const [currentPlanId, setCurrentPlanId] = useState<PlanId>("normal");
  const [subscriptionCurrency, setSubscriptionCurrency] = useState<CurrencyCode>("FCFA");
  const [contactSettings, setContactSettings] = useState({ name: "Junior Doukoua", email: "juniordoukoua@icloud.com", whatsapp: "+32 470 00 00 00", country: "Belgique" });
  const [automationRules, setAutomationRules] = useState({ confirmation: true, beforeDue: true, dueDay: true, lateReminder: true, receipt: true });
  const paymentDetailsRef = useRef(paymentDetails);
  paymentDetailsRef.current = paymentDetails;

  useEffect(() => {
    const saved = window.localStorage.getItem("patrimo-properties");
    if (saved) {
      try { setPropertyList(JSON.parse(saved)); } catch { /* conserve les biens par défaut */ }
    }
    const savedContacts = window.localStorage.getItem("patrimo-contact-settings");
    const savedRules = window.localStorage.getItem("patrimo-automation-rules");
    if (savedContacts) try { setContactSettings(JSON.parse(savedContacts)); } catch { /* conserve le profil */ }
    if (savedRules) try { setAutomationRules(JSON.parse(savedRules)); } catch { /* conserve les règles */ }

    const savedSubscription = window.localStorage.getItem("patrimo-subscription");
    if (savedSubscription) {
      try {
        const subscription = JSON.parse(savedSubscription) as { planId?: string; currency?: string };
        if (isPlanId(subscription.planId ?? null)) setCurrentPlanId(subscription.planId as PlanId);
        if (isCurrencyCode(subscription.currency ?? null)) setSubscriptionCurrency(subscription.currency as CurrencyCode);
      } catch { /* conserve la formule Normal */ }
    }

    const savedStripeTransactions = window.localStorage.getItem("patrimo-stripe-transactions");
    if (savedStripeTransactions) {
      try { setPaymentTransactions([...JSON.parse(savedStripeTransactions), ...initialTransactions]); } catch { /* conserve les transactions de démonstration */ }
    }

    fetch("/api/stripe/status", { headers: { accept: "application/json" } })
      .then((response) => response.json())
      .then((status: StripeStatus) => setStripeStatus(status))
      .catch(() => setStripeStatus({ configured: false, verified: false, mode: null, webhookConfigured: false }));
    fetch("/api/kkiapay/status", { headers: { accept: "application/json" } })
      .then((response) => response.json())
      .then((status: KkiapayStatus) => setKkiapayStatus(status))
      .catch(() => setKkiapayStatus({ configured: false, widgetConfigured: false, verificationConfigured: false, mode: "production", publicKey: null, callbackUrl: "" }));
  }, []);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const sharedPlan = params.get("subscribe");
    const sharedCurrency = params.get("currency");
    if (!isPlanId(sharedPlan)) return;
    const timer = window.setTimeout(() => {
      const currency = isCurrencyCode(sharedCurrency) ? sharedCurrency : "FCFA";
      const plan = getPlan(sharedPlan);
      const account = window.localStorage.getItem("patrimo-account");
      let client = contactSettings.name || "Client Nestelya";
      let email = contactSettings.email || "";
      if (account) try { const parsed=JSON.parse(account) as {name?:string;email?:string};client=parsed.name||client;email=parsed.email||email; } catch { /* conserve le profil */ }
      window.localStorage.setItem("patrimo-pending-subscription",JSON.stringify({planId:sharedPlan,currency,amount:plan.prices[currency],createdAt:new Date().toISOString()}));
      setSubscriptionCurrency(currency);
      setPaymentDetails({client,email,amount:String(plan.prices[currency]),currency,reason:`Abonnement ${plan.name} Nestelya · mensuel`,billingMode:"subscription",planId:sharedPlan,propertyLimit:plan.propertyLimit});
      setProvider(currency==="FCFA"?"Kkiapay":"Stripe");
      setShowDashboard(true);
      setActive("Abonnement");
      setPaymentModal(true);
    }, 0);
    return () => window.clearTimeout(timer);
  }, []);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get("pay") !== "1" || params.has("subscribe")) return;
    const amount = parseSharedAmount(params.get("amount"));
    const currency = isCurrencyCode(params.get("currency")) ? params.get("currency") as CurrencyCode : "FCFA";
    const requestedProvider = params.get("provider");
    const selectedProvider = requestedProvider === "Stripe" || requestedProvider === "Kkiapay" ? requestedProvider : currency === "FCFA" ? "Kkiapay" : "Stripe";
    if (!amount) {
      const invalidTimer = window.setTimeout(() => {
        setNotice("Ce lien de paiement est incomplet ou invalide");
        window.setTimeout(() => setNotice(""), 4200);
      }, 0);
      return () => window.clearTimeout(invalidTimer);
    }
    const timer = window.setTimeout(() => {
      setPaymentDetails({
        client: "Client Nestelya",
        email: "",
        amount,
        currency,
        reason: cleanSharedText(params.get("reason"), "Paiement immobilier Nestelya", 180),
        billingMode: "payment",
        planId: "",
        propertyLimit: null,
      });
      setProvider(selectedProvider);
      setShowDashboard(true);
      setActive("Paiements");
      setPaymentModal(true);
    }, 0);
    return () => window.clearTimeout(timer);
  }, []);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const stripeResult = params.get("stripe");
    if (!stripeResult) return;

    setShowDashboard(true);
    setActive("Paiements");
    const clearStripeParams = () => {
      params.delete("stripe");
      params.delete("session_id");
      const query = params.toString();
      window.history.replaceState({}, "", `${window.location.pathname}${query ? `?${query}` : ""}${window.location.hash}`);
    };

    if (stripeResult === "cancelled") {
      setNotice("Paiement Stripe annulé · aucun montant n’a été débité");
      window.setTimeout(() => setNotice(""), 4200);
      clearStripeParams();
      return;
    }

    const sessionId = params.get("session_id");
    if (!sessionId) {
      setNotice("Retour Stripe reçu, mais la transaction ne peut pas être vérifiée");
      clearStripeParams();
      return;
    }

    fetch(`/api/stripe/session?session_id=${encodeURIComponent(sessionId)}`, { headers: { accept: "application/json" } })
      .then((response) => response.json())
      .then((session: { ok?: boolean; paid?: boolean; amountTotal?: number; currency?: string; reference?: string; client?: string; reason?: string; planId?: string; billingMode?: string }) => {
        if (!session.ok) throw new Error("verification_failed");
        const currency = (session.currency || "eur").toUpperCase();
        const divisor = currency === "XOF" || currency === "JPY" ? 1 : 100;
        const amount = `${((session.amountTotal || 0) / divisor).toLocaleString("fr-FR", { maximumFractionDigits: 2 })} ${currency === "XOF" ? "FCFA" : currency}`;
        const transaction: PaymentTransaction = {
          client: session.client || "Client Stripe",
          ref: session.reference || sessionId.slice(0, 18),
          property: session.reason || "Paiement immobilier",
          method: "Stripe",
          amount,
          date: new Intl.DateTimeFormat("fr-FR", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" }).format(new Date()),
          status: session.paid ? "Payé" : "En attente",
        };
        const saved = JSON.parse(window.localStorage.getItem("patrimo-stripe-transactions") || "[]") as PaymentTransaction[];
        const withoutDuplicate = saved.filter((item) => item.ref !== transaction.ref);
        window.localStorage.setItem("patrimo-stripe-transactions", JSON.stringify([transaction, ...withoutDuplicate].slice(0, 25)));
        setPaymentTransactions([transaction, ...withoutDuplicate, ...initialTransactions]);
        if (session.paid && session.billingMode === "subscription" && isPlanId(session.planId ?? null)) {
          const planId = session.planId as PlanId;
          const savedCurrency = currency === "XOF" ? "FCFA" : isCurrencyCode(currency) ? currency : "EUR";
          window.localStorage.setItem("patrimo-subscription", JSON.stringify({ planId, currency: savedCurrency, status: "active", activatedAt: new Date().toISOString(), provider: "Stripe" }));
          window.localStorage.removeItem("patrimo-pending-subscription");
          setCurrentPlanId(planId);
          setSubscriptionCurrency(savedCurrency);
          setActive("Abonnement");
        }
        setNotice(session.paid ? "Paiement Stripe confirmé et enregistré" : "Paiement Stripe reçu · confirmation bancaire en attente");
        window.setTimeout(() => setNotice(""), 4200);
      })
      .catch(() => {
        setNotice("La transaction Stripe n’a pas pu être confirmée automatiquement");
        window.setTimeout(() => setNotice(""), 4200);
      })
      .finally(clearStripeParams);
  }, []);

  useEffect(() => {
    let listenersAttached = false;
    const showKkiapayNotice = (message: string) => {
      setNotice(message);
      window.setTimeout(() => setNotice(""), 4200);
    };

    const onSuccess = async (response: KkiapayResponse) => {
      const transactionId = response.transactionId || "";
      if (!transactionId) return showKkiapayNotice("Kkiapay n’a pas transmis de référence vérifiable. Aucun abonnement n’a été activé.");
      window.localStorage.setItem("patrimo-last-kkiapay", JSON.stringify({ transactionId, receivedAt: new Date().toISOString(), verified: false }));
      const pendingSubscription = window.localStorage.getItem("patrimo-pending-subscription");
      let planId: PlanId | null = null;
      let expectedAmount: number | null = null;
      if (pendingSubscription) {
        try {
          const subscription = JSON.parse(pendingSubscription) as { planId?: string; amount?: number };
          if (isPlanId(subscription.planId ?? null)) {
            planId = subscription.planId as PlanId;
            expectedAmount = Number(subscription.amount) || getPlan(planId).prices.FCFA;
          }
        } catch { /* la vérification serveur reste obligatoire */ }
      }
      if (!planId) {
        const regularAmount = parseSharedAmount(paymentDetailsRef.current.amount);
        expectedAmount = regularAmount ? Math.round(Number(regularAmount)) : null;
      }

      showKkiapayNotice(`Paiement Kkiapay reçu · vérification sécurisée de ${transactionId}…`);
      try {
        const verificationResponse = await fetch("/api/kkiapay/verify", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ transactionId, billingMode: planId ? "subscription" : "payment", planId, expectedAmount }),
        });
        const verification = await verificationResponse.json() as { verified?: boolean; amount?: number | null; status?: string; message?: string; sourceName?: string | null };
        if (!verificationResponse.ok || !verification.verified) {
          throw new Error(verification.message || "La transaction Kkiapay n’est pas encore confirmée ou son montant ne correspond pas.");
        }
        window.localStorage.setItem("patrimo-last-kkiapay", JSON.stringify({ transactionId, receivedAt: new Date().toISOString(), verified: true, amount: verification.amount, status: verification.status, source: verification.sourceName }));
        if (planId) {
          window.localStorage.setItem("patrimo-subscription", JSON.stringify({ planId, currency: "FCFA", status: "active", transactionId, activatedAt: new Date().toISOString(), provider: "Kkiapay" }));
          window.localStorage.removeItem("patrimo-pending-subscription");
          setCurrentPlanId(planId);
          setSubscriptionCurrency("FCFA");
          setActive("Abonnement");
        }
        setPaymentModal(false);
        setPaymentTab("Transactions");
        showKkiapayNotice(`Paiement Kkiapay confirmé et validé · référence ${transactionId}`);
      } catch (error) {
        showKkiapayNotice(error instanceof Error ? error.message : "La transaction Kkiapay n’a pas pu être validée.");
      }
    };
    const onFailed = () => showKkiapayNotice("Le paiement Kkiapay n’a pas abouti. Aucun encaissement n’a été enregistré.");
    const connectSdk = () => {
      if (!window.openKkiapayWidget) return false;
      const hasDedicatedListeners = Boolean(window.addSuccessListener && window.addFailedListener);
      const hasGenericListener = Boolean(window.addKkiapayListener);
      if (!hasDedicatedListeners && !hasGenericListener) return false;
      if (!listenersAttached) {
        if (hasDedicatedListeners) {
          window.addSuccessListener?.(onSuccess);
          window.addFailedListener?.(onFailed);
        } else {
          window.addKkiapayListener?.("success", onSuccess);
          window.addKkiapayListener?.("failed", onFailed);
        }
        listenersAttached = true;
      }
      setKkiapayReady(true);
      return true;
    };

    const poller = connectSdk() ? undefined : window.setInterval(() => {
      if (connectSdk()) window.clearInterval(poller);
    }, 200);

    return () => {
      if (poller) window.clearInterval(poller);
      if (listenersAttached) {
        window.removeKkiapayListener?.("success");
        window.removeKkiapayListener?.("failed");
      }
    };
  }, []);

  const act = (message: string) => {
    setNotice(message);
    window.setTimeout(() => setNotice(""), 2600);
  };

  const currentPlan = getPlan(currentPlanId);

  const openPropertyModal = () => {
    if (currentPlan.propertyLimit !== null && propertyList.length >= currentPlan.propertyLimit) {
      setActive("Abonnement");
      act(`Votre formule ${currentPlan.name} est limitée à ${currentPlan.propertyLimit} biens · choisissez une formule supérieure`);
      return;
    }
    setPropertyModal(true);
  };

  const openRegularPayment = () => {
    setPaymentDetails({ client: "Marc Kouassi", email: "", amount: "4000", currency: "FCFA", reason: "Loyer août 2026 · Appt. Plateau", billingMode: "payment", planId: "", propertyLimit: null });
    setKkiapayPhone("97000000");
    setProvider("Kkiapay");
    setPaymentModal(true);
  };

  const beginSubscription = (planId: PlanId, currency: CurrencyCode) => {
    const plan = getPlan(planId);
    const account = window.localStorage.getItem("patrimo-account");
    let accountName = contactSettings.name || "Client Nestelya";
    let accountEmail = contactSettings.email || "";
    if (account) {
      try {
        const parsed = JSON.parse(account) as { name?: string; email?: string };
        accountName = parsed.name || accountName;
        accountEmail = parsed.email || accountEmail;
      } catch { /* utilise les coordonnées du profil */ }
    }
    const pending = { planId, currency, amount: plan.prices[currency], createdAt: new Date().toISOString() };
    window.localStorage.setItem("patrimo-pending-subscription", JSON.stringify(pending));
    setSubscriptionCurrency(currency);
    setPaymentDetails({
      client: accountName,
      email: accountEmail,
      amount: String(plan.prices[currency]),
      currency,
      reason: `Abonnement ${plan.name} Nestelya · mensuel`,
      billingMode: "subscription",
      planId,
      propertyLimit: plan.propertyLimit,
    });
    setProvider(currency === "FCFA" ? "Kkiapay" : "Stripe");
    setShowDashboard(true);
    setActive("Abonnement");
    setPaymentModal(true);
  };

  const copySubscriptionLink = async (planId: PlanId, currency: CurrencyCode) => {
    const url = new URL(window.location.origin);
    url.searchParams.set("subscribe", planId);
    url.searchParams.set("currency", currency);
    url.hash = "tarifs";
    try {
      await navigator.clipboard.writeText(url.toString());
      act(`Lien de paiement ${getPlan(planId).name} copié · prêt pour WhatsApp ou e-mail`);
    } catch {
      window.prompt("Copiez ce lien de paiement", url.toString());
    }
  };

  const copyRegularPaymentLink = async () => {
    const amount = parseSharedAmount(paymentDetails.amount);
    if (!amount) return act("Saisissez un montant valide avant de créer le lien");
    const url = new URL(window.location.origin);
    url.searchParams.set("pay", "1");
    url.searchParams.set("amount", amount);
    url.searchParams.set("currency", paymentDetails.currency);
    url.searchParams.set("provider", provider === "Stripe" ? "Stripe" : "Kkiapay");
    url.searchParams.set("reason", cleanSharedText(paymentDetails.reason, "Paiement immobilier Nestelya", 180));
    try {
      await navigator.clipboard.writeText(url.toString());
      act(`Lien ${provider === "Stripe" ? "Stripe" : "Kkiapay"} copié · prêt pour WhatsApp ou e-mail`);
    } catch {
      window.prompt("Copiez ce lien de paiement sécurisé", url.toString());
    }
  };

  const addProperty = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (currentPlan.propertyLimit !== null && propertyList.length >= currentPlan.propertyLimit) {
      setPropertyModal(false);
      setActive("Abonnement");
      return act(`Limite de ${currentPlan.propertyLimit} biens atteinte pour la formule ${currentPlan.name}`);
    }
    const data = new FormData(event.currentTarget);
    const name = String(data.get("name") || "").trim();
    const city = String(data.get("city") || "").trim();
    const district = String(data.get("district") || "").trim();
    const type = String(data.get("type") || "Appartement");
    const rent = String(data.get("rent") || "0").trim();
    const rentValue = Number(rent.replace(/\s/g, "").replace(",", "."));
    const currency = String(data.get("currency") || "€");
    const status = String(data.get("status") || "Disponible");
    if (!name || !city || !Number.isFinite(rentValue) || rentValue <= 0) return act("Veuillez saisir un nom, une ville et un loyer valide");
    const newProperty = {
      id: `property-${Date.now()}`,
      name,
      place: district ? `${city} · ${district}` : city,
      type,
      value: `${rentValue.toLocaleString("fr-FR")} ${currency}`,
      meta: "Loyer mensuel",
      state: status,
      tone: status === "Occupé" ? "green" : status === "Réservé" ? "blue" : "amber",
      art: type === "Villa" ? "villa" : type === "Maison" ? "maison" : type === "Airbnb" ? "loft" : type === "Appartement" ? "azure" : "building",
    };
    const updated = [...propertyList, newProperty];
    setPropertyList(updated);
    window.localStorage.setItem("patrimo-properties", JSON.stringify(updated));
    setPropertyModal(false);
    setActive("Mes biens");
    act(`${name} a été ajouté à votre patrimoine`);
  };

  const launchPayment = async () => {
    if (provider !== "Stripe") {
      setPaymentModal(false);
      act(`Lien ${provider} créé et prêt à envoyer`);
      return;
    }

    setStripeLoading(true);
    try {
      const response = await fetch("/api/stripe/checkout", {
        method: "POST",
        headers: { "content-type": "application/json", "idempotency-key": crypto.randomUUID() },
        body: JSON.stringify(paymentDetails),
      });
      const result = await response.json() as { url?: string; message?: string };
      if (!response.ok || !result.url) throw new Error(result.message || "Stripe n’a pas pu ouvrir le paiement.");
      window.location.assign(result.url);
    } catch (error) {
      act(error instanceof Error ? error.message : "Stripe n’a pas pu ouvrir le paiement.");
      setStripeLoading(false);
    }
  };

  const openKkiapayPayment = () => {
    const amount = parseSharedAmount(paymentDetails.amount);
    const phone = kkiapayPhone.replace(/[^+0-9]/g, "");
    if (!amount) return act("Saisissez un montant Kkiapay valide");
    if (phone.replace(/\D/g, "").length < 8) return act("Saisissez un numéro de téléphone Kkiapay valide");
    if (!kkiapayReady || !window.openKkiapayWidget || !kkiapayStatus.publicKey) return act("Kkiapay est encore en cours d’initialisation");
    const options: Record<string, unknown> = {
      amount: Math.round(Number(amount)),
      key: kkiapayStatus.publicKey,
      api_key: kkiapayStatus.publicKey,
      sandbox: kkiapayStatus.mode === "test",
      phone,
      name: paymentDetails.client,
      reason: paymentDetails.reason,
    };
    if (kkiapayStatus.callbackUrl) options.callback = kkiapayStatus.callbackUrl;
    window.openKkiapayWidget(options);
  };

  if (!showDashboard) return <LandingPage onEnter={(section="Vue d’ensemble") => {setActive(section);setShowDashboard(true)}} onViewSubscriptions={() => {setActive("Abonnement");setShowDashboard(true)}} />;

  return (
    <main className="app-shell">
      {notice && <div className="toast" role="status">✓ {notice}</div>}
      <aside className={menu ? "sidebar open" : "sidebar"}>
        <button className="brand brand-button" onClick={() => setShowDashboard(false)} aria-label="Retour à la page d’accueil"><span className="brand-mark"><img className="brand-logo-img" src="/nestelya-logo.png" alt=""/></span><span>Nestelya</span></button>
        <button className="close-menu" aria-label="Fermer le menu" onClick={() => setMenu(false)}>×</button>
        <nav>
          <p className="nav-label">ESPACE DE GESTION</p>
          {nav.map((item, i) => <button key={item} className={active === item ? "nav-item active" : "nav-item"} onClick={() => {setActive(item); setMenu(false)}}><span className="nav-icon">{["⌂","▦","♙","◇","↗","◎","★","⚡","⌁","▤"][i]}</span>{item}{item === "Maintenance" && <em>3</em>}</button>)}
        </nav>
        <div className="sidebar-bottom">
          <button className="subscription-mini" onClick={()=>{setActive("Abonnement");setMenu(false)}}><span>{currentPlan.name.charAt(0)}</span><div><strong>Formule {currentPlan.name}</strong><small>{propertyList.length} / {currentPlan.propertyLimit ?? "∞"} biens utilisés</small></div><b>→</b></button>
          <a className="admin-entry" href="/admin"><span>★</span><strong>Administration</strong><small>Accès propriétaire sécurisé</small></a>
          <button className="help-card" onClick={() => act("L’assistant prépare une réponse")}><span>✦</span><strong>Besoin d’aide ?</strong><small>Demandez à l’assistant IA</small><i>→</i></button>
          <button className="profile" onClick={()=>{setActive("Automatisations");setMenu(false);act("Profil et coordonnées du compte ouverts")}}><span className="avatar">JD</span><span><strong>Junior Doukoua</strong><small>Propriétaire</small></span><b>···</b></button>
        </div>
      </aside>

      <section className="content">
        <header className="topbar">
          <button className="menu-btn" aria-label="Ouvrir le menu" onClick={() => setMenu(true)}>☰</button>
          <div className="search"><span>⌕</span><input aria-label="Rechercher" placeholder="Rechercher un bien, un locataire…"/><kbd>⌘ K</kbd></div>
          <div className="top-actions"><LanguageSwitcher compact/><button aria-label="Messages" onClick={() => act("Aucun nouveau message")}>♧</button><button className="bell" aria-label="Notifications" onClick={() => act("3 notifications à consulter")}>♢<i /></button><span className="top-avatar">JD</span></div>
        </header>

        <div className="dashboard">
          {active === "Paiements" ? (
            <PaymentCenter act={act} paymentTab={paymentTab} setPaymentTab={setPaymentTab} openModal={openRegularPayment} stripeStatus={stripeStatus} kkiapayStatus={kkiapayStatus} transactions={paymentTransactions} />
          ) : active === "Abonnement" ? (
            <SubscriptionCenter currentPlanId={currentPlanId} currency={subscriptionCurrency} setCurrency={setSubscriptionCurrency} propertyCount={propertyList.length} onSubscribe={beginSubscription} onCopyLink={copySubscriptionLink} />
          ) : active === "Automatisations" ? (
            <AutomationCenter
              settings={contactSettings}
              setSettings={setContactSettings}
              rules={automationRules}
              setRules={setAutomationRules}
              act={act}
              openPayment={openRegularPayment}
            />
          ) : active === "Mes biens" ? (
            <PropertiesModule properties={propertyList} onAdd={openPropertyModal} act={act} />
          ) : active === "Locataires" ? (
            <TenantsModule act={act} properties={propertyList} />
          ) : active === "Réservations" ? (
            <ReservationsModule act={act} properties={propertyList} />
          ) : active === "Finances" ? (
            <FinancesModule act={act} properties={propertyList} />
          ) : active === "Maintenance" ? (
            <MaintenanceModule act={act} properties={propertyList} />
          ) : active === "Documents" ? (
            <DocumentsModule act={act} properties={propertyList} />
          ) : (
          <>
          <div className="welcome-row">
            <div><p className="eyebrow">JEUDI 6 AOÛT</p><h1>Bonjour Junior, <span>tout est sous contrôle.</span></h1><p>Voici l’essentiel de votre patrimoine aujourd’hui.</p></div>
            <button className="primary" onClick={openPropertyModal}><span>＋</span> Ajouter un bien</button>
          </div>

          <div className="metrics">
            <article><div className="metric-top"><span className="metric-icon purple">▦</span><small className="up">↗ 8,4 %</small></div><p>Revenus ce mois</p><h2>12 480 €</h2><div className="spark"><i/><i/><i/><i/><i/><i/><i/><i/><i/></div><small>vs. 11 510 € le mois dernier</small></article>
            <article><div className="metric-top"><span className="metric-icon blue">⌂</span><small>{propertyList.length} biens</small></div><p>Taux d’occupation</p><h2>{propertyList.length ? Math.round((propertyList.filter(p => p.state === "Occupé" || p.state === "Réservé").length / propertyList.length) * 100) : 0} %</h2><div className="progress"><i style={{width:`${propertyList.length ? Math.round((propertyList.filter(p => p.state === "Occupé" || p.state === "Réservé").length / propertyList.length) * 100) : 0}%`}} /></div><small>{propertyList.filter(p => p.state === "Occupé").length} occupé(s) · {propertyList.filter(p => p.state === "Disponible").length} disponible(s)</small></article>
            <article><div className="metric-top"><span className="metric-icon amber">◷</span><small className="warn">À suivre</small></div><p>Paiements attendus</p><h2>2 760 €</h2><div className="progress amberbar"><i style={{width:"72%"}} /></div><small>4 loyers · échéance sous 5 jours</small></article>
            <article><div className="metric-top"><span className="metric-icon green">↗</span><small className="up">+ 1,7 pt</small></div><p>Rentabilité moyenne</p><h2>7,8 %</h2><div className="donut"><span>ROI</span></div><small>Objectif annuel : 8,5 %</small></article>
          </div>

          <div className="main-grid">
            <section className="panel properties">
              <div className="panel-title"><div><h3>Votre patrimoine</h3><p>Un aperçu rapide de vos biens</p></div><button onClick={() => {setActive("Mes biens"); act("Affichage de tous les biens")}}>Voir tous les biens →</button></div>
              <div className="property-grid">
                {propertyList.map((p) => <article className="property-card" key={p.id}>
                  <div className={`property-art ${p.art}`}><img src={getPropertyImage(p)} alt={`Vue extérieure de ${p.name}, ${p.type.toLowerCase()}`} loading="lazy" decoding="async"/><span className="type">{p.type}</span><button aria-label={`Options pour ${p.name}`} onClick={()=>{setActive("Mes biens");act(`Options de ${p.name} ouvertes`)}}>···</button></div>
                  <div className="property-info"><div><h4>{p.name}</h4><p>⌖ {p.place}</p></div><span className={`state ${p.tone}`}>● {p.state}</span><div className="property-value"><strong>{p.value}</strong><small>{p.meta}</small></div></div>
                </article>)}
              </div>
            </section>

            <aside className="panel actions-panel">
              <div className="panel-title"><div><h3>À faire aujourd’hui</h3><p>3 actions nécessitent votre attention</p></div><button className="dots" aria-label="Options des actions" onClick={()=>act("Options des actions ouvertes")}>···</button></div>
              <div className="task"><span className="task-icon red">!</span><div><strong>Loyer en retard</strong><p>Marc K. · Appt. Plateau</p><small>1 250 € · 6 jours de retard</small></div><button onClick={() => act("Relance WhatsApp envoyée à Marc")}>Relancer</button></div>
              <div className="task"><span className="task-icon amber">⌁</span><div><strong>Intervention à valider</strong><p>Fuite d’eau · Villa Riviera</p><small>Devis reçu : 180 €</small></div><button onClick={() => act("Intervention validée")}>Valider</button></div>
              <div className="task"><span className="task-icon blue">◇</span><div><strong>Arrivée demain à 15h</strong><p>Sarah M. · Loft Sablon</p><small>Check-in Airbnb</small></div><button onClick={() => act("Instructions envoyées à Sarah")}>Préparer</button></div>
              <button className="all-actions" onClick={() => act("Toutes les actions sont affichées")}>Voir toutes les actions <span>→</span></button>
            </aside>
          </div>

          <section className="bottom-grid">
            <article className="panel revenue-panel"><div className="panel-title"><div><h3>Revenus & dépenses</h3><p>Évolution sur les 6 derniers mois</p></div><select aria-label="Période"><option>6 derniers mois</option><option>12 derniers mois</option></select></div><div className="chart-legend"><span><i className="rev"/> Revenus</span><span><i className="exp"/> Dépenses</span></div><div className="chart"><div className="y-labels"><span>15k</span><span>10k</span><span>5k</span><span>0</span></div><div className="bars">{[[65,25],[72,31],[60,28],[84,33],[76,27],[92,35]].map((v,i)=><div className="bar-group" key={i}><div><i className="revenue" style={{height:`${v[0]}%`}}/><i className="expense" style={{height:`${v[1]}%`}}/></div><span>{["Mars","Avr.","Mai","Juin","Juil.","Août"][i]}</span></div>)}</div></div></article>
            <article className="panel occupancy"><div className="panel-title"><div><h3>Occupation</h3><p>Répartition de vos biens</p></div></div><div className="occupancy-body"><div className="big-donut"><div><strong>94%</strong><span>occupés</span></div></div><div className="occ-list"><p><i className="occ"/><span>Occupés</span><strong>11</strong></p><p><i className="avail"/><span>Disponibles</span><strong>1</strong></p><p><i className="maint"/><span>Maintenance</span><strong>0</strong></p></div></div></article>
          </section>
          </>
          )}
        </div>
      </section>
      {paymentModal && (
        <div className="modal-backdrop" role="presentation" onMouseDown={() => setPaymentModal(false)}>
          <section className="payment-modal" role="dialog" aria-modal="true" aria-labelledby="payment-title" onMouseDown={(e) => e.stopPropagation()}>
            <button className="modal-close" aria-label="Fermer" onClick={() => setPaymentModal(false)}>×</button>
            <span className="modal-icon">◎</span>
            <h2 id="payment-title">{paymentDetails.billingMode === "subscription" && paymentDetails.planId ? `Abonnement ${getPlan(paymentDetails.planId).name}` : provider === "Kkiapay" ? "Encaisser avec Kkiapay" : provider === "Stripe" ? "Encaisser avec Stripe" : "Créer un lien de paiement"}</h2>
            <p>{paymentDetails.billingMode === "subscription" ? "Finalisez la souscription mensuelle avec le moyen de paiement recommandé pour cette devise." : provider === "Kkiapay" ? "Ouvrez le paiement Mobile Money ou carte dans le widget sécurisé Kkiapay." : provider === "Stripe" ? "Ouvrez une page Stripe Checkout officielle pour payer par carte ou portefeuille numérique." : "Envoyez un lien sécurisé par WhatsApp, SMS ou e-mail."}</p>
            {paymentDetails.billingMode === "subscription" && paymentDetails.planId && <div className="subscription-payment-summary"><span>{getPlan(paymentDetails.planId).name.charAt(0)}</span><div><strong>{getPlan(paymentDetails.planId).name} · {formatPlanPrice(getPlan(paymentDetails.planId),paymentDetails.currency)} / mois</strong><small>{getPlan(paymentDetails.planId).propertyLimit===null?"Nombre de biens illimité":`Jusqu’à ${getPlan(paymentDetails.planId).propertyLimit} biens`}</small></div></div>}
            <label>{paymentDetails.billingMode === "subscription" ? "Titulaire du compte" : "Locataire ou client"}<input value={paymentDetails.client} onChange={(event) => setPaymentDetails((current) => ({ ...current, client: event.target.value }))} /></label>
            {provider === "Stripe" && <label>E-mail du payeur <input type="email" placeholder="client@email.com (optionnel)" value={paymentDetails.email} onChange={(event) => setPaymentDetails((current) => ({ ...current, email: event.target.value }))} /></label>}
            <div className="field-row"><label>Montant<input inputMode="numeric" value={paymentDetails.amount} readOnly={paymentDetails.billingMode === "subscription"} onChange={(event) => setPaymentDetails((current) => ({ ...current, amount: event.target.value }))} /></label><label>Devise<select value={paymentDetails.currency} onChange={(event) => {const currency=event.target.value as CurrencyCode;setPaymentDetails((current) => ({ ...current, currency, amount:current.billingMode==="subscription"&&current.planId?String(getPlan(current.planId).prices[currency]):current.amount }));if(paymentDetails.billingMode==="subscription")setProvider(currency==="FCFA"?"Kkiapay":"Stripe")}}>{CURRENCIES.map(currency=><option key={currency.code} value={currency.code}>{currency.code} · {currency.label}</option>)}</select></label></div>
            <label>Prestataire</label>
            <div className="provider-choice">
              {(paymentDetails.billingMode === "subscription" ? ["Kkiapay","Stripe"] : ["Kkiapay","Stripe","Chariow"]).map((name) => <button key={name} className={provider === name ? "selected" : ""} onClick={() => {setProvider(name);if(name==="Kkiapay"){setPaymentDetails(current=>({...current,currency:"FCFA",amount:current.billingMode==="subscription"&&current.planId?String(getPlan(current.planId).prices.FCFA):current.amount}))}else if(paymentDetails.billingMode==="subscription"){const currency:CurrencyCode=paymentDetails.currency==="FCFA"?"EUR":paymentDetails.currency;setPaymentDetails(current=>({...current,currency,amount:current.planId?String(getPlan(current.planId).prices[currency]):current.amount}))}}}><i className={name.toLowerCase()}>{name.charAt(0)}</i>{name}</button>)}
            </div>
            <label>Motif<input value={paymentDetails.reason} onChange={(event) => setPaymentDetails((current) => ({ ...current, reason: event.target.value }))} /></label>
            {provider === "Kkiapay" && <label>Téléphone Mobile Money<input inputMode="tel" value={kkiapayPhone} onChange={(event)=>setKkiapayPhone(event.target.value)} placeholder="97000000" /></label>}
            {provider === "Kkiapay" ? <div className="kkiapay-widget-wrap"><button className="create-link" type="button" disabled={!kkiapayReady || !kkiapayStatus.widgetConfigured || !kkiapayStatus.publicKey} onClick={openKkiapayPayment}>{kkiapayReady && kkiapayStatus.widgetConfigured ? "Ouvrir le paiement Kkiapay" : kkiapayStatus.widgetConfigured ? "Initialisation de Kkiapay…" : "Configuration Kkiapay requise"} <span>→</span></button></div> : <button className="create-link" disabled={stripeLoading} onClick={launchPayment}>{provider === "Stripe" ? stripeLoading ? "Connexion sécurisée à Stripe…" : "Continuer vers Stripe Checkout" : "Générer le lien sécurisé"} <span>→</span></button>}
            {paymentDetails.billingMode === "payment" && provider !== "Chariow" && <button className="copy-payment-link" type="button" onClick={copyRegularPaymentLink}>⌁ Copier le lien à envoyer</button>}
            <small className="security-note">{provider === "Kkiapay" ? kkiapayStatus.configured ? `⌾ Kkiapay ${kkiapayStatus.mode === "production" ? "Production" : "Test"} · validation serveur active avant activation` : "⌾ Ajoutez les trois clés Kkiapay dans les paramètres sécurisés" : provider === "Stripe" ? stripeStatus.verified ? `⌾ Stripe ${stripeStatus.mode === "production" ? "Production" : "Test"} vérifié · ${paymentDetails.billingMode === "subscription" ? "renouvellement mensuel automatique" : "confirmation sécurisée côté serveur"}${stripeStatus.webhookConfigured ? " · webhook actif" : " · webhook à configurer"}` : stripeStatus.configured ? "⌾ Clé Stripe présente mais non validée · vérifiez ses autorisations" : "⌾ API Stripe prête · ajoutez la clé secrète dans les paramètres sécurisés" : "⌾ Paiement chiffré · Aucun numéro de carte n’est conservé"}</small>
          </section>
        </div>
      )}
      {propertyModal && (
        <div className="modal-backdrop" role="presentation" onMouseDown={() => setPropertyModal(false)}>
          <section className="payment-modal property-modal" role="dialog" aria-modal="true" aria-labelledby="property-title" onMouseDown={(e) => e.stopPropagation()}>
            <button className="modal-close" aria-label="Fermer" onClick={() => setPropertyModal(false)}>×</button>
            <span className="modal-icon">⌂</span>
            <h2 id="property-title">Ajouter un nouveau bien</h2>
            <p>Renseignez les informations principales. Vous pourrez ajouter les photos et documents ensuite.</p>
            <form onSubmit={addProperty}>
              <label>Nom du bien *<input name="name" placeholder="Ex. Villa Lagune" required autoFocus /></label>
              <div className="property-form-grid">
                <label>Type de bien *<select name="type" defaultValue="Appartement"><option>Appartement</option><option>Maison</option><option>Villa</option><option>Immeuble</option><option>Bureau</option><option>Commerce</option><option>Terrain</option><option>Hôtel</option><option>Airbnb</option></select></label>
                <label>Statut<select name="status" defaultValue="Disponible"><option>Disponible</option><option>Occupé</option><option>Réservé</option></select></label>
              </div>
              <div className="property-form-grid">
                <label>Ville *<input name="city" placeholder="Ex. Abidjan" required /></label>
                <label>Quartier<input name="district" placeholder="Ex. Cocody" /></label>
              </div>
              <div className="field-row rent-row">
                <label>Loyer mensuel *<input name="rent" inputMode="decimal" placeholder="Ex. 450000" required /></label>
                <label>Devise<select name="currency" defaultValue="FCFA"><option>FCFA</option><option>€</option><option>$</option><option>£</option><option>¥</option></select></label>
              </div>
              <label>Description<textarea name="description" rows={3} placeholder="Description courte du bien…" /></label>
              <div className="upload-placeholder"><span>＋</span><div><strong>Ajouter des photos</strong><small>Vous pourrez les importer depuis la fiche du bien</small></div></div>
              <div className="add-property-actions"><button type="button" onClick={() => setPropertyModal(false)}>Annuler</button><button type="submit">Ajouter le bien <span>→</span></button></div>
            </form>
          </section>
        </div>
      )}
    </main>
  );
}

function SubscriptionCenter({currentPlanId,currency,setCurrency,propertyCount,onSubscribe,onCopyLink}:{currentPlanId:PlanId;currency:CurrencyCode;setCurrency:(currency:CurrencyCode)=>void;propertyCount:number;onSubscribe:(planId:PlanId,currency:CurrencyCode)=>void;onCopyLink:(planId:PlanId,currency:CurrencyCode)=>void}) {
  const currentPlan=getPlan(currentPlanId);
  const usage=currentPlan.propertyLimit===null?34:Math.min(100,Math.round((propertyCount/currentPlan.propertyLimit)*100));
  return <div className="subscription-page">
    <div className="welcome-row subscription-head"><div><p className="eyebrow">ABONNEMENT & FACTURATION</p><h1>Choisissez votre formule</h1><p>Gérez votre limite de biens et partagez un lien de paiement dans la devise du client.</p></div><div className="subscription-live"><i/> FORMULE {currentPlan.name.toUpperCase()}</div></div>
    <section className="panel subscription-overview"><div className="subscription-overview-copy"><span>{currentPlan.name.charAt(0)}</span><div><small>FORMULE ACTUELLE</small><h2>{currentPlan.name}</h2><p>{currentPlan.subtitle}</p></div></div><div className="subscription-usage"><div><span>Biens utilisés</span><strong>{propertyCount} / {currentPlan.propertyLimit ?? "Illimité"}</strong></div><div className="subscription-progress"><i style={{width:`${usage}%`}}/></div><small>{currentPlan.propertyLimit===null?"Aucune limite de biens":`${Math.max(0,currentPlan.propertyLimit-propertyCount)} emplacement(s) encore disponible(s)`}</small></div><div className="subscription-billing"><span>Prochain renouvellement</span><strong>6 septembre 2026</strong><small>{formatPlanPrice(currentPlan,currency)} · mensuel</small></div></section>
    <div className="subscription-toolbar"><div><h3>Les 3 formules Nestelya</h3><p>FCFA via Kkiapay · devises internationales via Stripe</p></div><div className="currency-switch compact" role="group" aria-label="Devise des abonnements">{CURRENCIES.map(item=><button key={item.code} className={currency===item.code?"active":""} onClick={()=>setCurrency(item.code)}>{item.label}</button>)}</div></div>
    <div className="subscription-plan-grid">{SUBSCRIPTION_PLANS.map(plan=><article key={plan.id} className={`${plan.featured?"subscription-plan featured":"subscription-plan"}${plan.id===currentPlanId?" current":""}`}>{plan.featured&&<span className="plan-ribbon">RECOMMANDÉ</span>}<div className="subscription-plan-title"><span>{plan.name.charAt(0)}</span><div><h3>{plan.name}</h3><p>{plan.subtitle}</p></div>{plan.id===currentPlanId&&<em>ACTUEL</em>}</div><div className="subscription-plan-price"><strong>{formatPlanPrice(plan,currency)}</strong><small>/ mois</small></div><div className="subscription-plan-limit">{plan.propertyLimit===null?"∞ biens":"Jusqu’à "+plan.propertyLimit+" biens"}</div><ul>{plan.features.map(feature=><li key={feature}><i>✓</i>{feature}</li>)}</ul><button className="subscription-action" onClick={()=>onSubscribe(plan.id,currency)}>{plan.id===currentPlanId?"Renouveler cette formule":`Choisir ${plan.name}`} <span>→</span></button><button className="copy-payment-link" onClick={()=>onCopyLink(plan.id,currency)}>⌁ Copier le lien de paiement</button><small className="subscription-provider">{currency==="FCFA"?"Kkiapay · Mobile Money & carte":"Stripe Checkout · carte & wallet"}</small></article>)}</div>
    <div className="subscription-assurance"><span>✓ Paiement sécurisé</span><span>↻ Facturation mensuelle</span><span>⌁ Lien partageable</span><span>◇ Changement de formule à tout moment</span></div>
  </div>;
}

function PaymentCenter({ act, paymentTab, setPaymentTab, openModal, stripeStatus, kkiapayStatus, transactions }: { act: (message: string) => void; paymentTab: string; setPaymentTab: (tab: string) => void; openModal: () => void; stripeStatus: StripeStatus; kkiapayStatus: KkiapayStatus; transactions: PaymentTransaction[] }) {
  return (
    <div className="payments-page">
      <div className="welcome-row payments-head">
        <div><p className="eyebrow">PAIEMENTS & ENCAISSEMENTS</p><h1>Centre de paiement</h1><p>Encaissez vos loyers et réservations partout, en toute sécurité.</p></div>
        <button className="primary" onClick={openModal}><span>＋</span> Créer un lien de paiement</button>
      </div>
      <div className="payment-metrics">
        <article><span className="pay-metric-icon success">↗</span><div><p>Encaissé ce mois</p><h2>12 480 €</h2><small>+8,4 % vs. juillet</small></div></article>
        <article><span className="pay-metric-icon pending">◷</span><div><p>En attente</p><h2>2 760 €</h2><small>4 paiements</small></div></article>
        <article><span className="pay-metric-icon fee">%</span><div><p>Frais de transaction</p><h2>186,40 €</h2><small>1,42 % en moyenne</small></div></article>
        <article><span className="pay-metric-icon rate">✓</span><div><p>Taux de réussite</p><h2>97,8 %</h2><small>162 paiements réussis</small></div></article>
      </div>
      <section className="providers-section">
        <div className="section-heading"><div><h3>Prestataires de paiement</h3><p>Choisissez la solution adaptée à chaque locataire.</p></div><span className="live-mode">● KKIAPAY {kkiapayStatus.configured ? kkiapayStatus.mode === "production" ? "PRODUCTION" : "TEST" : "À CONFIGURER"} · STRIPE {stripeStatus.verified ? stripeStatus.mode === "production" ? "PRODUCTION" : "TEST" : "À CONFIGURER"}</span></div>
        <div className="provider-grid">
          <ProviderCard kind="kkiapay" name="Kkiapay" subtitle="Mobile Money Afrique" text="Orange Money, MTN MoMo, Moov Money, Wave et cartes bancaires." tags={["FCFA","Mobile Money","Visa"]} fee="Commission dès 1,5 %" status={kkiapayStatus.configured ? kkiapayStatus.mode === "production" ? "Production" : "Mode test" : "À configurer"} act={act}/>
          <ProviderCard kind="stripe" name="Stripe" subtitle="Checkout & API sécurisée" text="Visa, Mastercard, Apple Pay, Google Pay et confirmation serveur par webhook." tags={["EUR","USD","FCFA","Wallets"]} fee="Tarifs selon votre compte Stripe" status={stripeStatus.verified ? stripeStatus.mode === "production" ? "Production" : "Mode test" : "À configurer"} act={act}/>
          <ProviderCard kind="chariow" name="Chariow" subtitle="Liens de paiement rapides" text="Pages de paiement personnalisées, reçus automatiques et suivi client." tags={["Multi-devise","Liens","Reçus"]} fee="Activation selon votre compte" status="Prêt" act={act}/>
        </div>
      </section>
      <section className="panel transactions-panel">
        <div className="transaction-top"><div><h3>Activité des paiements</h3><p>Suivez tous les encaissements en temps réel.</p></div><div className="payment-tabs">{["Transactions","Liens actifs","Remboursements"].map(tab => <button className={paymentTab === tab ? "active" : ""} onClick={() => setPaymentTab(tab)} key={tab}>{tab}</button>)}</div><button className="export-btn" onClick={() => act("Export des paiements préparé")}>⇩ Exporter</button></div>
        {paymentTab === "Transactions" ? <div className="transaction-table"><div className="table-row table-head"><span>CLIENT</span><span>BIEN / RÉFÉRENCE</span><span>MOYEN</span><span>DATE</span><span>MONTANT</span><span>STATUT</span></div>{transactions.map((t) => <div className="table-row" key={t.ref}><span className="client-cell"><i>{t.client.split(" ").map(n => n[0]).join("")}</i><strong>{t.client}</strong></span><span><strong>{t.property}</strong><small>{t.ref}</small></span><span className={`method ${t.method.toLowerCase()}`}>{t.method.charAt(0)} <b>{t.method}</b></span><span>{t.date}</span><span><strong>{t.amount}</strong></span><span className={t.status === "Payé" ? "paid-status" : "pending-status"}>● {t.status}</span></div>)}</div> : <div className="empty-payment-state"><span>{paymentTab === "Liens actifs" ? "↗" : "↶"}</span><h4>{paymentTab}</h4><p>{paymentTab === "Liens actifs" ? "Créez votre premier lien de paiement sécurisé." : "Aucun remboursement enregistré ce mois-ci."}</p>{paymentTab === "Liens actifs" && <button onClick={openModal}>Créer un lien</button>}</div>}
      </section>
      <div className="payments-footer"><span>⌾ Paiements sécurisés et conformes</span><span>✓ Reçus automatiques</span><span>⌁ Relances WhatsApp</span><span>↻ Rapprochement bancaire</span></div>
    </div>
  );
}

function ProviderCard({kind,name,subtitle,text,tags,fee,status,act}:{kind:string;name:string;subtitle:string;text:string;tags:string[];fee:string;status:string;act:(message:string)=>void}) {
  const connected = status === "Production" || status === "Mode test";
  const message = name === "Stripe" && !connected ? "Ajoutez STRIPE_SECRET_KEY et STRIPE_WEBHOOK_SECRET dans les paramètres sécurisés" : `${name} · ${status}`;
  return <article className={`provider-card ${kind}-card`}><div className="provider-brand"><i>{name.charAt(0)}</i><div><strong>{name}</strong><small>{subtitle}</small></div><span className={connected ? "provider-live" : status === "À configurer" ? "provider-pending" : ""}>{status}</span></div><p>{text}</p><div className="provider-tags">{tags.map(tag=><span key={tag}>{tag}</span>)}</div><div className="provider-foot"><small>{fee}</small><button onClick={() => act(message)}>Configurer →</button></div></article>
}

type ContactSettings = { name: string; email: string; whatsapp: string; country: string };
type AutomationRules = { confirmation: boolean; beforeDue: boolean; dueDay: boolean; lateReminder: boolean; receipt: boolean };

function AutomationCenter({ settings, setSettings, rules, setRules, act, openPayment }: { settings: ContactSettings; setSettings: (value: ContactSettings) => void; rules: AutomationRules; setRules: (value: AutomationRules) => void; act: (message: string) => void; openPayment: () => void }) {
  const updateRule = (key: keyof AutomationRules) => {
    const updated = { ...rules, [key]: !rules[key] };
    setRules(updated);
    window.localStorage.setItem("patrimo-automation-rules", JSON.stringify(updated));
  };
  const saveContacts = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    window.localStorage.setItem("patrimo-contact-settings", JSON.stringify(settings));
    act("Coordonnées de notification enregistrées");
  };
  const ruleRows: Array<{key:keyof AutomationRules;icon:string;title:string;text:string;time:string}> = [
    {key:"confirmation",icon:"✓",title:"Confirmation de paiement",text:"Envoyer immédiatement après chaque paiement réussi.",time:"Immédiat"},
    {key:"beforeDue",icon:"◷",title:"Rappel avant échéance",text:"Prévenir le locataire avant la date du loyer.",time:"J-5 et J-2"},
    {key:"dueDay",icon:"◇",title:"Rappel le jour de l’échéance",text:"Envoyer le montant et le lien de paiement personnel.",time:"Jour J · 09:00"},
    {key:"lateReminder",icon:"!",title:"Relance automatique d’impayé",text:"Relancer progressivement tant que le paiement manque.",time:"J+3, J+7, J+15"},
    {key:"receipt",icon:"▤",title:"Quittance et reçu",text:"Transmettre automatiquement le PDF après encaissement.",time:"Après paiement"},
  ];
  return <div className="automation-page">
    <div className="welcome-row automation-head"><div><p className="eyebrow">COMMUNICATION INTELLIGENTE</p><h1>Automatisations WhatsApp & e-mail</h1><p>Chaque utilisateur reçoit ses confirmations et rappels sur ses coordonnées personnelles.</p></div><span className="automation-status">● AUTOMATISATIONS ACTIVES</span></div>
    <div className="automation-layout">
      <section className="panel contact-settings">
        <div className="automation-title"><span className="wa-icon">◉</span><div><h3>Coordonnées du compte</h3><p>Destination des confirmations et alertes personnelles</p></div></div>
        <form onSubmit={saveContacts}>
          <label>Nom complet<input value={settings.name} onChange={e=>setSettings({...settings,name:e.target.value})}/></label>
          <label>Numéro WhatsApp<input type="tel" value={settings.whatsapp} onChange={e=>setSettings({...settings,whatsapp:e.target.value})}/><small>Incluez l’indicatif du pays, par exemple +225</small></label>
          <label>Adresse e-mail<input type="email" value={settings.email} onChange={e=>setSettings({...settings,email:e.target.value})}/></label>
          <label>Pays<select value={settings.country} onChange={e=>setSettings({...settings,country:e.target.value})}><option>Belgique</option><option>Côte d’Ivoire</option><option>France</option><option>Italie</option><option>Sénégal</option><option>Autre</option></select></label>
          <div className="channel-preview"><span>◉ WhatsApp</span><b>+</b><span>✉ E-mail</span><i>Double confirmation activée</i></div>
          <button className="save-settings" type="submit">Enregistrer les coordonnées</button>
        </form>
      </section>
      <section className="panel rules-panel">
        <div className="panel-title"><div><h3>Scénarios automatiques</h3><p>Activez ou désactivez chaque envoi</p></div><button onClick={()=>act("Message test envoyé sur WhatsApp et e-mail")}>Envoyer un test</button></div>
        <div className="rule-list">{ruleRows.map(row=><article className="automation-rule" key={row.key}><span className={`rule-icon ${row.key}`}>{row.icon}</span><div><strong>{row.title}</strong><p>{row.text}</p><small>{row.time}</small></div><button role="switch" aria-checked={rules[row.key]} className={rules[row.key]?"toggle on":"toggle"} onClick={()=>updateRule(row.key)}><i/></button></article>)}</div>
      </section>
    </div>
    <section className="panel reminder-flow">
      <div className="panel-title"><div><h3>Parcours automatique d’un paiement</h3><p>De la première notification jusqu’à la quittance</p></div><button onClick={openPayment}>＋ Créer un lien de paiement</button></div>
      <div className="flow-steps"><article><span>1</span><strong>Loyer généré</strong><small>Calcul automatique</small></article><i>→</i><article><span>2</span><strong>Lien sécurisé</strong><small>Kkiapay · Stripe · Chariow</small></article><i>→</i><article><span>3</span><strong>Envoi personnel</strong><small>WhatsApp + e-mail</small></article><i>→</i><article><span>4</span><strong>Suivi automatique</strong><small>Rappels et relances</small></article><i>→</i><article><span>5</span><strong>Paiement confirmé</strong><small>Reçu + quittance PDF</small></article></div>
    </section>
    <div className="integration-note"><span>i</span><p><strong>Connexion des services requise</strong> Pour envoyer réellement les messages, connectez l’API WhatsApp Business et votre service e-mail dans les paramètres administrateur.</p><button onClick={()=>act("Assistant de connexion des services ouvert")}>Configurer les services →</button></div>
  </div>;
}
