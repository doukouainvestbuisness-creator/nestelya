import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { LanguageProvider } from "./language";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Nestelya — Votre patrimoine, simplement",
  description: "Nestelya automatise la gestion de vos biens, loyers, réservations, paiements et interventions depuis un espace sécurisé.",
  applicationName: "Nestelya",
  keywords: ["gestion immobilière", "gestion locative", "patrimoine", "Airbnb", "loyers", "maintenance immobilière", "Nestelya"],
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: "/nestelya-logo.png",
    shortcut: "/nestelya-logo.png",
    apple: "/nestelya-logo.png",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fr">
      <head>
        <script src="https://cdn.kkiapay.me/k.js" defer></script>
      </head>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased`}
      >
        <LanguageProvider>{children}</LanguageProvider>
      </body>
    </html>
  );
}
