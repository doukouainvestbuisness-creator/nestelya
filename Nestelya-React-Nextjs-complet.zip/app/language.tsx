"use client";

import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";

export type Language = "fr" | "en";

type LanguageContextValue = {
  language: Language;
  setLanguage: (language: Language) => void;
};

const LanguageContext = createContext<LanguageContextValue>({ language: "fr", setLanguage: () => undefined });

const TRANSLATIONS: Record<string, string> = {
  // Navigation et compte
  "Fonctionnalités": "Features", "Tarifs": "Pricing", "Sécurité": "Security", "Connexion": "Log in",
  "Créer un compte": "Create account", "Se connecter": "Log in", "Fermer": "Close", "Fermer le menu": "Close menu",
  "Retour à la page d’accueil": "Back to home page", "Vue d’ensemble": "Overview", "Mes biens": "My properties",
  "Locataires": "Tenants", "Réservations": "Bookings", "Finances": "Finances", "Paiements": "Payments",
  "Abonnement": "Subscription", "Automatisations": "Automations", "Documents": "Documents",
  "ESPACE DE GESTION": "MANAGEMENT AREA", "Rechercher un bien, un locataire…": "Search for a property or tenant…",
  "Administration": "Administration", "Accès propriétaire sécurisé": "Secure owner access", "Besoin d’aide ?": "Need help?",
  "Demandez à l’assistant IA": "Ask the AI assistant", "Propriétaire": "Owner", "Profil": "Profile",
  "Agence immobilière": "Real estate agency", "Gestionnaire": "Manager", "Syndic": "Property manager", "Investisseur": "Investor",

  // Page d’accueil
  "La gestion immobilière réinventée par l’IA": "Property management reinvented by AI",
  "Nestelya · La gestion immobilière réinventée par l’IA": "Nestelya · Property management reinvented by AI",
  "Votre patrimoine, simplement.": "Your property portfolio, made simple.",
  "Votre patrimoine.": "Your portfolio.", "Géré sans stress.": "Managed without stress.",
  "Loyers, réservations, locataires, maintenance et paiements : Nestelya automatise tout, pendant que vous profitez de l’essentiel.": "Rent, bookings, tenants, maintenance and payments: Nestelya automates everything while you focus on what matters.",
  "Découvrir mon tableau de bord": "Explore my dashboard", "Voir comment ça fonctionne": "See how it works",
  "Sans installation": "No installation", "Accessible partout": "Available anywhere", "Paiements sécurisés": "Secure payments",
  "Performance du mois": "This month’s performance", "Revenus encaissés": "Revenue collected", "Tout est sous contrôle": "Everything is under control",
  "ABONNEMENTS": "SUBSCRIPTIONS", "Une formule adaptée à chaque patrimoine.": "A plan for every portfolio.",
  "Choisissez votre devise et recevez un lien de paiement sécurisé. Les abonnements sont facturés chaque mois.": "Choose your currency and receive a secure payment link. Subscriptions are billed monthly.",
  "Choisir la devise": "Choose currency", "Pour démarrer sereinement": "A confident start",
  "Pour un patrimoine en croissance": "For a growing portfolio", "Pour gérer sans aucune limite": "Unlimited portfolio management",
  "Jusqu’à 10 biens": "Up to 10 properties", "De 11 à 20 biens": "11 to 20 properties", "Biens illimités": "Unlimited properties",
  "Gestion des loyers et locataires": "Rent and tenant management", "Liens de paiement": "Payment links",
  "Rappels WhatsApp et e-mail": "WhatsApp and email reminders", "Toutes les fonctions Normal": "All Normal plan features",
  "États des lieux numériques": "Digital property inspections", "Rapports financiers avancés": "Advanced financial reports",
  "Toutes les fonctions Classique": "All Classic plan features", "Automatisations prioritaires": "Priority automations",
  "Assistance premium": "Premium support", "LE PLUS CHOISI": "MOST POPULAR",
  "Voir tous les détails": "View all details", "Voir tous les détails →": "View all details →",
  "Choisir Normal": "Choose Normal", "Choisir Classique": "Choose Classic", "Choisir Excellent": "Choose Excellent",
  "Paiement Kkiapay · Mobile Money": "Kkiapay payment · Mobile Money", "Paiement Stripe · Carte bancaire": "Stripe payment · Bank card",
  "Les montants internationaux sont des tarifs localisés fixes. Vous pouvez changer de formule à tout moment.": "International amounts are fixed local prices. You can change plans at any time.",
  "UNE PLATEFORME PENSÉE POUR": "A PLATFORM BUILT FOR", "Propriétaires": "Property owners",
  "Agences immobilières": "Real estate agencies", "Locations Airbnb": "Airbnb rentals",
  "Gestionnaires de patrimoine": "Property managers", "Syndics": "Property management firms",
  "TOUT-EN-UN": "ALL IN ONE", "Un seul espace pour tout gérer.": "One place to manage everything.",
  "Centralisez votre patrimoine et automatisez chaque tâche, depuis votre téléphone ou votre ordinateur.": "Centralize your portfolio and automate every task from your phone or computer.",
  "PATRIMOINE": "PORTFOLIO", "Tous vos biens, en un coup d’œil": "All your properties at a glance",
  "Maisons, appartements, immeubles ou Airbnb : suivez l’occupation, la valeur et la rentabilité de chaque bien.": "Houses, apartments, buildings or Airbnb: monitor occupancy, value and returns for every property.",
  "Gérer mes biens": "Manage my properties", "PAIEMENTS": "PAYMENTS", "Encaissez simplement, partout": "Collect payments easily, anywhere",
  "Kkiapay, Stripe, Mobile Money et cartes bancaires réunis pour des paiements fluides et des quittances automatiques.": "Kkiapay, Stripe, Mobile Money and bank cards come together for smooth payments and automatic receipts.",
  "Voir les paiements": "View payments", "AUTOMATISATION": "AUTOMATION", "WhatsApp travaille pour vous": "WhatsApp works for you",
  "Confirmations, rappels de loyer, relances et liens de paiement sont envoyés automatiquement au bon moment.": "Confirmations, rent reminders, follow-ups and payment links are sent automatically at the right time.",
  "Découvrir l’automatisation": "Explore automation", "INTELLIGENCE IMMOBILIÈRE": "PROPERTY INTELLIGENCE",
  "Anticipez avant même": "Anticipate issues before", "que les problèmes arrivent.": "they even happen.",
  "L’intelligence artificielle détecte les impayés, les dépenses inhabituelles et les maintenances à prévoir. Vous êtes alerté, Nestelya prépare l’action.": "AI detects late payments, unusual spending and upcoming maintenance. You receive the alert and Nestelya prepares the next action.",
  "Risques détectés automatiquement": "Risks detected automatically", "Scores locataires et anomalies financières": "Tenant scores and financial anomalies",
  "Interventions mieux organisées": "Better organized interventions", "Priorité, technicien et suivi centralisé": "Priority, technician and centralized tracking",
  "Vos données restent protégées": "Your data stays protected", "Chiffrement, sauvegardes et journal d’audit": "Encryption, backups and audit log",
  "Entrer dans Nestelya": "Enter Nestelya", "ALERTE INTELLIGENTE": "SMART ALERT", "Risque d’impayé détecté": "Late-payment risk detected",
  "Relance WhatsApp programmée": "WhatsApp follow-up scheduled", "Climatisation à contrôler": "Air conditioning check due",
  "Échéance dans 8 jours": "Due in 8 days", "VALEUR DU PATRIMOINE": "PORTFOLIO VALUE", "Prévision actualisée": "Updated forecast",
  "CONTACT & ASSISTANCE": "CONTACT & SUPPORT", "Parlons de votre patrimoine.": "Let’s talk about your portfolio.",
  "Une question sur Nestelya ou besoin d’un accompagnement ? Envoyez-nous un message ou échangez directement sur WhatsApp.": "Have a question about Nestelya or need guidance? Send us a message or chat directly on WhatsApp.",
  "Assistance WhatsApp": "WhatsApp support", "Échange rapide depuis votre téléphone": "Quick support from your phone",
  "Ouvrir WhatsApp": "Open WhatsApp", "Assistance par e-mail": "Email support", "Réponse personnalisée à votre demande": "A personalized reply to your request",
  "Écrire un e-mail": "Send an email", "Envoyez-nous un message": "Send us a message", "Nous vous répondrons par e-mail ou WhatsApp.": "We will reply by email or WhatsApp.",
  "Nom complet *": "Full name *", "Nom complet": "Full name", "Votre nom": "Your name", "Adresse e-mail *": "Email address *",
  "Adresse e-mail": "Email address", "Numéro WhatsApp": "WhatsApp number", "Sujet": "Subject",
  "Découvrir Nestelya": "Discover Nestelya", "Créer mon compte": "Create my account", "Paiements et Mobile Money": "Payments and Mobile Money",
  "Assistance technique": "Technical support", "Autre demande": "Other request", "Votre message *": "Your message *",
  "Expliquez-nous votre besoin…": "Tell us what you need…", "Envoyer ma demande": "Send my request",
  "Votre demande a bien été préparée dans votre messagerie.": "Your request has been prepared in your email app.",
  "Votre patrimoine mérite mieux": "Your portfolio deserves better", "Pilotez tout. Sans vous compliquer la vie.": "Run everything. Without the hassle.",
  "Rejoignez une nouvelle façon de gérer l’immobilier : plus simple, plus intelligente et toujours accessible.": "Join a new way to manage property: simpler, smarter and always accessible.",
  "Créer mon compte gratuitement": "Create my free account", "Le gestionnaire immobilier intelligent, partout avec vous.": "The smart property manager, wherever you are.",
  "Tous droits réservés.": "All rights reserved.", "Ravi de vous revoir.": "Welcome back.",
  "Connectez-vous pour accéder à votre patrimoine.": "Log in to access your portfolio.", "Mot de passe": "Password",
  "Votre mot de passe": "Your password", "Se souvenir de moi": "Remember me", "Mot de passe oublié ?": "Forgot password?",
  "Créez votre espace.": "Create your workspace.", "Commencez à gérer votre patrimoine plus simplement.": "Start managing your portfolio more easily.",
  "Pays": "Country", "Autre": "Other", "Créer un mot de passe": "Create a password", "8 caractères minimum": "At least 8 characters",
  "J’accepte les conditions d’utilisation et la politique de confidentialité.": "I accept the terms of use and privacy policy.",
  "Connexion sécurisée · Données chiffrées": "Secure login · Encrypted data",

  // Dashboard et biens
  "Bonjour Junior,": "Hello Junior,", "tout est sous contrôle.": "everything is under control.",
  "Voici l’essentiel de votre patrimoine aujourd’hui.": "Here is today’s portfolio overview.", "Ajouter un bien": "Add property",
  "Revenus ce mois": "Revenue this month", "Taux d’occupation": "Occupancy rate", "Paiements attendus": "Expected payments",
  "À suivre": "Monitor", "Rentabilité moyenne": "Average return", "Objectif annuel": "Annual target",
  "Votre patrimoine": "Your portfolio", "Un aperçu rapide de vos biens": "A quick overview of your properties",
  "Voir tous les biens": "View all properties", "Loyer mensuel": "Monthly rent", "Occupé": "Occupied", "Réservé": "Booked",
  "Disponible": "Available", "Villa": "Villa", "Maison": "House", "Appartement": "Apartment", "Immeuble": "Building",
  "Bureau": "Office", "Commerce": "Retail space", "Terrain": "Land", "Hôtel": "Hotel",
  "À faire aujourd’hui": "Today’s tasks", "actions nécessitent votre attention": "tasks need your attention",
  "Loyer en retard": "Overdue rent", "jours de retard": "days overdue", "Relancer": "Send reminder",
  "Intervention à valider": "Intervention to approve", "Fuite d’eau": "Water leak", "Devis reçu": "Quote received",
  "Valider": "Approve", "Arrivée demain à 15h": "Arrival tomorrow at 3 p.m.", "Préparer": "Prepare",
  "Voir toutes les actions": "View all tasks", "Revenus & dépenses": "Revenue & expenses",
  "Évolution sur les 6 derniers mois": "Trend over the last 6 months", "6 derniers mois": "Last 6 months", "12 derniers mois": "Last 12 months",
  "Revenus": "Revenue", "Dépenses": "Expenses", "Occupation": "Occupancy", "Répartition de vos biens": "Property distribution",
  "Disponibles": "Available", "Gérez vos logements, leurs équipements, services et performances.": "Manage your properties, equipment, services and performance.",
  "Total des biens": "Total properties", "catégories actives": "active categories", "Biens occupés": "Occupied properties",
  "Prêt à être loué": "Ready to rent", "Équipements": "Equipment", "contrôle à prévoir": "check due",
  "Tous les biens": "All properties", "Équipements & options": "Equipment & options", "Services inclus": "Included services",
  "LOYER / PERFORMANCE": "RENT / PERFORMANCE", "ÉQUIPEMENTS": "EQUIPMENT", "Voir la fiche": "View details",
  "Inventaire des équipements": "Equipment inventory", "Suivi par bien, état et prochaine maintenance": "Tracking by property, condition and next maintenance",
  "Ajouter un équipement": "Add equipment", "Nom de l’équipement": "Equipment name", "Confort": "Comfort", "Énergie": "Energy",
  "Électroménager": "Appliances", "Plomberie": "Plumbing", "Enregistrer": "Save", "Annuler": "Cancel",
  "ÉQUIPEMENT": "EQUIPMENT", "BIEN": "PROPERTY", "CATÉGORIE": "CATEGORY", "ÉTAT": "CONDITION",
  "PROCHAINE MAINTENANCE": "NEXT MAINTENANCE", "Bon état": "Good condition", "À contrôler": "Check required",
  "Wi-Fi haut débit": "High-speed Wi-Fi", "Inclus dans 3 logements": "Included in 3 properties", "Ménage": "Cleaning",
  "Après chaque réservation": "After every booking", "Check-in autonome": "Self check-in", "Serrures intelligentes": "Smart locks",
  "Dépannage 24/7": "24/7 assistance", "Assistance prioritaire": "Priority support", "Climatisation": "Air conditioning",
  "Maintenance programmée": "Scheduled maintenance", "places disponibles": "spaces available", "Configurer": "Configure",
  "Ajouter un nouveau bien": "Add a new property", "Renseignez les informations principales. Vous pourrez ajouter les photos et documents ensuite.": "Enter the main information. You can add photos and documents afterwards.",
  "Nom du bien *": "Property name *", "Ex. Villa Lagune": "E.g. Lagoon Villa", "Type de bien *": "Property type *",
  "Statut": "Status", "Ville *": "City *", "Ex. Abidjan": "E.g. Abidjan", "Quartier": "District", "Ex. Cocody": "E.g. Cocody",
  "Loyer mensuel *": "Monthly rent *", "Devise": "Currency", "Description": "Description",
  "Description courte du bien…": "Short property description…", "Ajouter des photos": "Add photos",
  "Vous pourrez les importer depuis la fiche du bien": "You can upload them from the property details page", "Ajouter le bien": "Add property",

  // Locataires, réservations, finances
  "RELATION LOCATAIRE": "TENANT RELATIONSHIP", "Dossiers, contrats, paiements et communication centralisés.": "Centralized files, contracts, payments and communication.",
  "Nouveau locataire": "New tenant", "Locataires actifs": "Active tenants", "À jour": "Up to date", "Dossiers réguliers": "Accounts in good standing",
  "En retard": "Overdue", "À relancer": "Follow-up required", "Score moyen IA": "Average AI score", "Fiabilité élevée": "High reliability",
  "Rechercher un locataire…": "Search tenants…", "Tous les statuts": "All statuses", "Exporter": "Export", "Score IA": "AI score",
  "LOYER": "RENT", "Voir le dossier": "View file", "Ajouter un nouveau locataire": "Add a new tenant",
  "Créez son dossier et associez-le à un bien.": "Create their file and link it to a property.", "Bien loué *": "Rented property *",
  "WhatsApp / téléphone *": "WhatsApp / phone *", "Profession": "Occupation", "Garant": "Guarantor", "Nom du garant": "Guarantor’s name",
  "Loyer *": "Rent *", "Début du bail *": "Lease start date *", "Ajouter le locataire": "Add tenant",
  "LOCATION COURTE DURÉE": "SHORT-TERM RENTALS", "Calendriers, arrivées, départs et canaux de réservation synchronisés.": "Synchronized calendars, arrivals, departures and booking channels.",
  "Nouvelle réservation": "New booking", "Ce mois-ci": "This month", "Revenus prévus": "Expected revenue",
  "Arrivées aujourd’hui": "Arrivals today", "Prochaine à 15h": "Next at 3 p.m.", "Nuits réservées": "Booked nights",
  "Planning des séjours": "Stay schedule", "Liste": "List", "Calendrier": "Calendar", "SÉJOUR": "STAY", "MONTANT": "AMOUNT",
  "Confirmée": "Confirmed", "En attente": "Pending", "Voir": "View", "Ajouter une réservation": "Add booking",
  "Enregistrez le séjour et préparez la confirmation du voyageur.": "Record the stay and prepare the guest confirmation.",
  "Nom du voyageur *": "Guest name *", "Bien *": "Property *", "Arrivée *": "Arrival *", "Départ *": "Departure *",
  "Montant total *": "Total amount *", "Canal": "Channel", "Contact WhatsApp / e-mail": "WhatsApp / email contact",
  "Ajouter la réservation": "Add booking", "PERFORMANCE FINANCIÈRE": "FINANCIAL PERFORMANCE",
  "Analysez vos revenus, dépenses, cash-flow et rentabilité.": "Analyze revenue, expenses, cash flow and returns.",
  "Ajouter une dépense": "Add expense", "opérations": "transactions", "Cash-flow net": "Net cash flow", "Après charges": "After expenses",
  "Rentabilité": "Return", "Cash-flow mensuel": "Monthly cash flow", "Revenus et dépenses sur 8 mois": "Revenue and expenses over 8 months",
  "Répartition des dépenses": "Expense breakdown", "dépenses": "expenses", "Charges": "Utilities", "Taxes": "Taxes", "Assurances": "Insurance",
  "Dernières opérations": "Latest transactions", "Mouvements récents": "Recent activity", "Exporter le rapport": "Export report",
  "Revenu": "Revenue", "Dépense": "Expense", "Enregistrez une charge et rattachez-la au bien concerné.": "Record an expense and link it to the relevant property.",
  "Libellé *": "Description *", "Catégorie": "Category", "Bien concerné": "Related property", "Portefeuille général": "General portfolio",
  "Fournisseur *": "Supplier *", "Montant *": "Amount *", "Date *": "Date *", "Mode de paiement": "Payment method",
  "Carte bancaire": "Bank card", "Virement": "Bank transfer", "Espèces": "Cash", "Justificatif": "Receipt",
  "Enregistrer la dépense": "Save expense",

  // Maintenance et documents
  "SUIVI TECHNIQUE": "TECHNICAL TRACKING", "Centralisez les incidents, techniciens et entretiens préventifs.": "Centralize incidents, technicians and preventive maintenance.",
  "Signaler un incident": "Report incident", "Tickets ouverts": "Open tickets", "En cours": "In progress", "Techniciens assignés": "Assigned technicians",
  "Résolus": "Resolved", "Délai moyen": "Average response time", "Interventions en cours": "Ongoing interventions",
  "Priorité, statut et coût estimé": "Priority, status and estimated cost", "Voir l’historique": "View history", "Signalé par": "Reported by",
  "Urgent": "Urgent", "Moyen": "Medium", "Faible": "Low", "STATUT": "STATUS", "COÛT": "COST",
  "Maintenance préventive": "Preventive maintenance", "Prochaines échéances": "Upcoming due dates", "Chaque lundi": "Every Monday",
  "Récurrent": "Recurring", "Voir le calendrier": "View calendar",
  "Décrivez le problème. La priorité et le suivi seront ajoutés immédiatement.": "Describe the issue. Priority and tracking will be added immediately.",
  "Incident *": "Incident *", "Bien concerné *": "Related property *", "Signalé par *": "Reported by *",
  "Description détaillée *": "Detailed description *", "Niveau d’urgence": "Urgency level", "Photos ou vidéo": "Photos or video",
  "Notifier le propriétaire et le locataire par WhatsApp et e-mail": "Notify the owner and tenant by WhatsApp and email",
  "Créer le ticket d’incident": "Create incident ticket", "COFFRE-FORT NUMÉRIQUE": "DIGITAL VAULT",
  "Contrats, quittances, assurances et états des lieux sécurisés.": "Secure contracts, receipts, insurance and inspections.",
  "Ajouter un document": "Add document", "Toutes catégories": "All categories", "Signés": "Signed", "Signature électronique": "Electronic signature",
  "À renouveler": "Renewal due", "Sous 30 jours": "Within 30 days", "Stockage": "Storage", "Chiffré et sécurisé": "Encrypted and secure",
  "Importer un document": "Upload a document", "PDF, Word, image ou feuille de calcul": "PDF, Word, image or spreadsheet", "Ajouter": "Add",
  "Rechercher un document…": "Search documents…", "Toutes les catégories": "All categories", "Contrats": "Contracts",
  "Quittances": "Rent receipts", "Factures": "Invoices", "États des lieux": "Inspections", "Diagnostics": "Certificates",
  "Synchroniser": "Sync", "NOM": "NAME", "DATE": "DATE", "TAILLE": "SIZE",

  // Abonnements, paiements et automatisations
  "ABONNEMENT & FACTURATION": "SUBSCRIPTION & BILLING", "Choisissez votre formule": "Choose your plan",
  "Gérez votre limite de biens et partagez un lien de paiement dans la devise du client.": "Manage your property limit and share a payment link in the client’s currency.",
  "FORMULE ACTUELLE": "CURRENT PLAN", "Biens utilisés": "Properties used", "Illimité": "Unlimited", "Aucune limite de biens": "No property limit",
  "Prochain renouvellement": "Next renewal", "Les 3 formules Nestelya": "Nestelya’s 3 plans",
  "FCFA via Kkiapay · devises internationales via Stripe": "FCFA via Kkiapay · international currencies via Stripe",
  "Devise des abonnements": "Subscription currency", "RECOMMANDÉ": "RECOMMENDED", "ACTUEL": "CURRENT", "biens": "properties",
  "Renouveler cette formule": "Renew this plan", "Copier le lien de paiement": "Copy payment link",
  "Kkiapay · Mobile Money & carte": "Kkiapay · Mobile Money & card", "Stripe Checkout · carte & wallet": "Stripe Checkout · card & wallet",
  "Paiement sécurisé": "Secure payment", "Facturation mensuelle": "Monthly billing", "Lien partageable": "Shareable link",
  "Changement de formule à tout moment": "Change plan at any time", "PAIEMENTS & ENCAISSEMENTS": "PAYMENTS & COLLECTIONS",
  "Centre de paiement": "Payment center", "Encaissez vos loyers et réservations partout, en toute sécurité.": "Collect rent and booking payments anywhere, securely.",
  "Créer un lien de paiement": "Create payment link", "Encaissé ce mois": "Collected this month", "paiements": "payments",
  "Frais de transaction": "Transaction fees", "en moyenne": "on average", "Taux de réussite": "Success rate", "paiements réussis": "successful payments",
  "Prestataires de paiement": "Payment providers", "Choisissez la solution adaptée à chaque locataire.": "Choose the right solution for each tenant.",
  "ACTIF": "ACTIVE", "À CONFIGURER": "TO CONFIGURE", "Mobile Money Afrique": "African Mobile Money",
  "Orange Money, MTN MoMo, Moov Money, Wave et cartes bancaires.": "Orange Money, MTN MoMo, Moov Money, Wave and bank cards.",
  "Commission dès 1,5 %": "Fees from 1.5%", "Production": "Production", "Checkout & API sécurisée": "Secure Checkout & API",
  "Visa, Mastercard, Apple Pay, Google Pay et confirmation serveur par webhook.": "Visa, Mastercard, Apple Pay, Google Pay and server confirmation by webhook.",
  "Tarifs selon votre compte Stripe": "Pricing based on your Stripe account", "À configurer": "To configure",
  "Liens de paiement rapides": "Quick payment links", "Pages de paiement personnalisées, reçus automatiques et suivi client.": "Custom payment pages, automatic receipts and client tracking.",
  "Multi-devise": "Multi-currency", "Liens": "Links", "Reçus": "Receipts", "Activation selon votre compte": "Activation based on your account",
  "Prêt": "Ready", "Activité des paiements": "Payment activity", "Suivez tous les encaissements en temps réel.": "Track every payment in real time.",
  "Transactions": "Transactions", "Liens actifs": "Active links", "Remboursements": "Refunds", "CLIENT": "CLIENT",
  "BIEN / RÉFÉRENCE": "PROPERTY / REFERENCE", "MOYEN": "METHOD", "Payé": "Paid",
  "Créez votre premier lien de paiement sécurisé.": "Create your first secure payment link.", "Aucun remboursement enregistré ce mois-ci.": "No refunds recorded this month.",
  "Créer un lien": "Create link", "Paiements sécurisés et conformes": "Secure and compliant payments", "Reçus automatiques": "Automatic receipts",
  "Relances WhatsApp": "WhatsApp follow-ups", "Rapprochement bancaire": "Bank reconciliation", "Locataire ou client": "Tenant or client",
  "Montant": "Amount", "Prestataire": "Provider", "Motif": "Reason", "Encaisser avec Kkiapay": "Collect with Kkiapay",
  "Encaisser avec Stripe": "Collect with Stripe", "Ouvrez le paiement Mobile Money ou carte dans le widget sécurisé Kkiapay.": "Open Mobile Money or card payment in the secure Kkiapay widget.",
  "Ouvrez une page Stripe Checkout officielle pour payer par carte ou portefeuille numérique.": "Open an official Stripe Checkout page to pay by card or digital wallet.",
  "Envoyez un lien sécurisé par WhatsApp, SMS ou e-mail.": "Send a secure link by WhatsApp, SMS or email.",
  "Titulaire du compte": "Account holder", "E-mail du payeur": "Payer email", "Continuer vers Stripe Checkout": "Continue to Stripe Checkout",
  "Générer le lien sécurisé": "Generate secure link", "Initialisation de Kkiapay…": "Initializing Kkiapay…",
  "Connexion sécurisée à Stripe…": "Secure connection to Stripe…", "Paiement chiffré · Aucun numéro de carte n’est conservé": "Encrypted payment · No card number is stored",
  "COMMUNICATION INTELLIGENTE": "SMART COMMUNICATION", "Automatisations WhatsApp & e-mail": "WhatsApp & email automations",
  "Chaque utilisateur reçoit ses confirmations et rappels sur ses coordonnées personnelles.": "Each user receives confirmations and reminders through their personal contact details.",
  "AUTOMATISATIONS ACTIVES": "AUTOMATIONS ACTIVE", "Coordonnées du compte": "Account contact details",
  "Destination des confirmations et alertes personnelles": "Destination for personal confirmations and alerts",
  "Incluez l’indicatif du pays, par exemple +225": "Include the country code, for example +225", "Double confirmation activée": "Dual confirmation enabled",
  "Enregistrer les coordonnées": "Save contact details", "Scénarios automatiques": "Automation scenarios",
  "Activez ou désactivez chaque envoi": "Enable or disable each message", "Envoyer un test": "Send test",
  "Confirmation de paiement": "Payment confirmation", "Envoyer immédiatement après chaque paiement réussi.": "Send immediately after every successful payment.",
  "Immédiat": "Immediate", "Rappel avant échéance": "Reminder before due date", "Prévenir le locataire avant la date du loyer.": "Notify the tenant before rent is due.",
  "Rappel le jour de l’échéance": "Due-date reminder", "Envoyer le montant et le lien de paiement personnel.": "Send the amount and personal payment link.",
  "Relance automatique d’impayé": "Automatic overdue follow-up", "Relancer progressivement tant que le paiement manque.": "Send progressive follow-ups until payment is received.",
  "Quittance et reçu": "Rent receipt and payment receipt", "Transmettre automatiquement le PDF après encaissement.": "Automatically send the PDF after collection.",
  "Après paiement": "After payment", "Parcours automatique d’un paiement": "Automated payment journey",
  "De la première notification jusqu’à la quittance": "From the first notification to the receipt", "Loyer généré": "Rent generated",
  "Calcul automatique": "Automatic calculation", "Lien sécurisé": "Secure link", "Envoi personnel": "Personal delivery",
  "Suivi automatique": "Automatic tracking", "Rappels et relances": "Reminders and follow-ups", "Paiement confirmé": "Payment confirmed",
  "Reçu + quittance PDF": "Receipt + PDF rent receipt", "Connexion des services requise": "Service connection required",
  "Pour envoyer réellement les messages, connectez l’API WhatsApp Business et votre service e-mail dans les paramètres administrateur.": "To send messages, connect the WhatsApp Business API and your email service in the admin settings.",
  "Configurer les services": "Configure services",

  // Administration
  "Pilotage": "Overview", "CRM & clients": "CRM & clients", "Abonnements": "Subscriptions", "Support & accès": "Support & access",
  "Super Administrateur": "Super Administrator", "Accès propriétaire": "Owner access", "CENTRE DE CONTRÔLE": "CONTROL CENTER",
  "Revenir au site": "Back to site", "ADMINISTRATION PROPRIÉTAIRE": "OWNER ADMINISTRATION",
  "Centre de contrôle Nestelya": "Nestelya control center", "Année": "Year",
  "Bonjour Junior, voici l’état complet du site.": "Hello Junior, here is the full site status.",
  "Activité, revenus récurrents, clients et santé technique réunis en un seul espace.": "Activity, recurring revenue, clients and technical health in one place.",
  "Tous les services sont opérationnels": "All services are operational", "Revenus récurrents": "Recurring revenue",
  "sur un an": "year over year", "Clients actifs": "Active clients", "ce mois-ci": "this month",
  "Abonnements actifs": "Active subscriptions", "de conversion": "conversion", "Volume encaissé": "Collected volume",
  "transactions": "transactions", "Évolution annuelle": "Annual trend", "Revenus récurrents et nouveaux clients en": "Recurring revenue and new clients in",
  "Revenu mensuel récurrent": "Monthly recurring revenue", "Prévision fin d’année": "Year-end forecast",
  "Ce qui fonctionne": "What is working", "Performance par module": "Performance by module", "Détails": "Details",
  "Paiements & relances": "Payments & follow-ups", "Gestion des biens": "Property management", "Réservations Airbnb": "Airbnb bookings",
  "Répartition des abonnements": "Subscription breakdown", "actifs": "active", "Gérer": "Manage",
  "Santé de la plateforme": "Platform health", "Surveillance des services critiques": "Critical service monitoring",
  "Application web": "Web application", "Base de données": "Database", "Paiements Kkiapay": "Kkiapay payments",
  "Opérationnel": "Operational", "Configuration requise": "Configuration required", "Connexion requise": "Connection required",
  "Sauvegarde automatique": "Automatic backup", "Suivez chaque client, son engagement, ses paiements et ses demandes.": "Track every client, their engagement, payments and requests.",
  "Résolvez les problèmes de connexion et sécurisez les comptes clients.": "Resolve login issues and secure client accounts.",
  "Nouvelle action": "New action", "Rechercher un client, un e-mail ou un abonnement…": "Search for a client, email or subscription…",
  "ABONNEMENT": "SUBSCRIPTION", "VALEUR ANNUELLE": "ANNUAL VALUE", "DERNIÈRE ACTIVITÉ": "LAST ACTIVITY", "ACTIONS": "ACTIONS",
  "Actif": "Active", "Accès bloqué": "Access blocked", "Taux de conversion": "Conversion rate", "Essai vers abonnement": "Trial to subscription",
  "Taux de résiliation": "Churn rate", "point ce mois": "point this month", "Répartition": "Breakdown", "Revenu mensuel": "Monthly revenue",
  "Modifier la formule": "Edit plan", "Copier le lien": "Copy link", "Tarification internationale activée": "International pricing enabled",
  "EUR, USD, GBP et JPY sont encaissés via Stripe. Le FCFA est encaissé via Kkiapay.": "EUR, USD, GBP and JPY are collected through Stripe. FCFA is collected through Kkiapay.",
  "Gérer les devises": "Manage currencies", "Vue générale": "Overview", "Activité récente": "Recent activity", "Paramètres": "Settings",
  "Alertes et anomalies": "Alerts and anomalies", "Historique annuel": "Annual history", "Rapports": "Reports",
  "Consultez et gérez les informations de": "View and manage information for", "depuis ce panneau.": "from this panel.", "Ouvrir": "Open",
  "Valeur annuelle": "Annual value", "Dernière activité": "Last activity", "2FA recommandée": "2FA recommended",
  "Assistance et accès": "Support and access", "Réinitialiser le mot de passe": "Reset password",
  "Envoyer un lien sécurisé par e-mail": "Send a secure link by email", "Fermer toutes les sessions": "Close all sessions",
  "Déconnecter le compte sur tous les appareils": "Sign the account out on all devices", "Rétablir l’accès au compte": "Restore account access",
  "Débloquer et renvoyer les instructions": "Unlock and resend instructions", "Suspendre le compte": "Suspend account",
  "Bloquer temporairement toute connexion": "Temporarily block all logins",
  "Toutes les actions administrateur sont enregistrées dans le journal d’audit.": "All administrator actions are recorded in the audit log.",

  // Dates et libellés courants
  "Aujourd’hui": "Today", "Hier": "Yesterday", "Fév": "Feb", "Avr": "Apr", "Juin": "Jun", "Juil": "Jul",
  "Août": "Aug", "Déc": "Dec", "Lun": "Mon", "Mer": "Wed", "Jeu": "Thu", "Ven": "Fri", "Sam": "Sat", "Dim": "Sun",
  "JEUDI 6 AOÛT": "THURSDAY, AUGUST 6",

  // Compléments d’interface et données d’exemple
  "Classique": "Classic", "Belgique": "Belgium", "Côte d’Ivoire": "Ivory Coast", "Italie": "Italy", "Sénégal": "Senegal",
  "Voir tous les biens →": "View all properties →", "Formule": "Plan", "Occupés": "Occupied",
  "vs. 11 510 € le mois dernier": "vs. €11,510 last month", "Objectif annuel : 8,5 %": "Annual target: 8.5%",
  "Exporter le rapport →": "Export report →", "⇩ Exporter": "⇩ Export", "✉ Envoyer un e-mail": "✉ Send an email",
  "Voir le dossier →": "View file →", "Voir →": "View →", "Configurer →": "Configure →",
  "Voir l’historique →": "View history →", "Voir le calendrier →": "View calendar →", "↻ Synchroniser": "↻ Sync",
  "⌁ Copier le lien de paiement": "⌁ Copy payment link", "＋ Créer un lien de paiement": "＋ Create payment link",
  "Configurer les services →": "Configure services →", "FORMULE NORMAL": "NORMAL PLAN", "/ mois": "/ month",
  "Nombre de biens illimité": "Unlimited number of properties", "∞ biens": "∞ properties", "mensuel": "monthly",
  "+12 % ce mois": "+12% this month", "+8,4 % ce mois": "+8.4% this month", "Objectif 8,5 %": "Target 8.5%",
  "Loyer Villa Riviera": "Villa Riviera rent", "Réparation plomberie": "Plumbing repair",
  "Réservation Loft Sablon": "Loft Sablon booking", "Assurance habitation": "Home insurance",
  "ACTIVITÉ": "ACTIVITY", "CONFIGURER": "CONFIGURE", "AUTOMATISATIONS ACTIVES": "AUTOMATIONS ACTIVE",
  "● AUTOMATISATIONS ACTIVES": "● AUTOMATIONS ACTIVE", "J-5 et J-2": "D-5 and D-2", "Jour J · 09:00": "Due day · 09:00",
  "WhatsApp + e-mail": "WhatsApp + email", "Technicien assigné": "Technician assigned", "Planifié": "Scheduled",
  "Fuite sous évier": "Leak under sink", "Climatisation bruyante": "Noisy air conditioning", "Serrure connectée": "Smart lock",
  "Extincteurs": "Fire extinguishers", "Chaudière": "Boiler", "Piscine": "Pool",
  "⌾ Paiements sécurisés et conformes": "⌾ Secure and compliant payments", "✓ Reçus automatiques": "✓ Automatic receipts",
  "⌁ Relances WhatsApp": "⌁ WhatsApp follow-ups", "↻ Rapprochement bancaire": "↻ Bank reconciliation",
  "● KKIAPAY ACTIF · STRIPE TO CONFIGURE": "● KKIAPAY ACTIVE · STRIPE TO CONFIGURE",
  "Mai": "May", "Mars": "March", "Avr.": "Apr", "Juil.": "Jul",
  "occupé(s) ·": "occupied ·", "disponible(s)": "available", "occupés": "occupied",
  "Envoyer un e-mail": "Send an email", "FORMULE": "PLAN", "· mensuel": "· monthly",
  "Fuite d’eau · Villa Riviera": "Water leak · Villa Riviera", "Devis reçu : 180 €": "Quote received: €180",
  "● KKIAPAY ACTIF · STRIPE": "● KKIAPAY ACTIVE · STRIPE", "J+3, J+7, J+15": "D+3, D+7, D+15",
  "✓ Paiement sécurisé": "✓ Secure payment", "↻ Facturation mensuelle": "↻ Monthly billing",
  "⌁ Lien partageable": "⌁ Shareable link", "◇ Changement de formule à tout moment": "◇ Change plan at any time",
  "jours de retard": "days overdue", "· Signalé par": "· Reported by", "abonnements actifs": "active subscriptions",
};

const DYNAMIC_RULES: Array<[RegExp, string]> = [
  [/^(\d+) biens$/, "$1 properties"], [/^Sur (\d+) bien\(s\)$/, "Across $1 property/properties"],
  [/^Jusqu’à (\d+) biens$/, "Up to $1 properties"], [/^De (\d+) à (\d+) biens$/, "$1 to $2 properties"],
  [/^(\d+) nuit$/, "$1 night"], [/^(\d+) nuits$/, "$1 nights"], [/^(\d+) jours?$/, "$1 days"],
  [/^(\d+) opérations?$/, "$1 transactions"], [/^(\d+) intervention\(s\) urgente\(s\)$/, "$1 urgent intervention(s)"],
  [/^(\d+) emplacement\(s\) encore disponible\(s\)$/, "$1 slot(s) remaining"], [/^Il y a (.+)$/, "$1 ago"],
  [/^Aujourd’hui · (.+)$/, "Today · $1"], [/^Hier · (.+)$/, "Yesterday · $1"], [/^Hier à (.+)$/, "Yesterday at $1"],
  [/^JEUDI 6 AOÛT (\d{4})$/, "THURSDAY, AUGUST 6, $1"], [/^Formule (.+)$/, "$1 plan"], [/^Choisir (.+)$/, "Choose $1"],
  [/^Options de (.+) ouvertes$/, "$1 options opened"], [/^Fiche de (.+) ouverte$/, "$1 details opened"],
  [/^(.+) a été ajouté à votre patrimoine$/, "$1 was added to your portfolio"], [/^(.+) a été ajouté comme locataire$/, "$1 was added as a tenant"],
  [/^Réservation de (.+) ajoutée et confirmation prête$/, "$1 booking added and confirmation ready"],
  [/^Dépense « (.+) » enregistrée$/, "Expense “$1” saved"], [/^Incident « (.+) » signalé avec priorité (.+)$/, "Incident “$1” reported with $2 priority"],
  [/^Lien (.+) copié · prêt à partager$/, "$1 link copied · ready to share"],
  [/^Lien de paiement (.+) copié · prêt pour WhatsApp ou e-mail$/, "$1 payment link copied · ready for WhatsApp or email"],
  [/^(\d+) catégories actives$/, "$1 active categories"], [/^([\d,.]+) % d’occupation$/, "$1% occupancy"],
  [/^(\d+) contrôles? à prévoir$/, "$1 check(s) due"], [/^(\d+) occupé\(s\) · (\d+) disponible\(s\)$/, "$1 occupied · $2 available"],
  [/^(\d+) loyers · échéance sous (\d+) jours$/, "$1 rents · due within $2 days"],
  [/^vs\. ([\d\s,.]+) € le mois dernier$/, "vs. €$1 last month"], [/^Objectif annuel : ([\d,.]+) %$/, "Annual target: $1%"],
  [/^([+−-]?[\d,.]+) % ce mois$/, "$1% this month"], [/^([+−-]?[\d,.]+) % vs\. juillet$/, "$1% vs. July"],
  [/^(\d+) paiements$/, "$1 payments"], [/^([\d,.]+) % en moyenne$/, "$1% on average"], [/^(\d+) paiements réussis$/, "$1 successful payments"],
  [/^(\d+) \/ (\d+) biens utilisés$/, "$1 / $2 properties used"], [/^(\d+) \/ (∞|\d+) biens utilisés$/, "$1 / $2 properties used"],
  [/^(.+) · Signalé par (.+)$/, "$1 · Reported by $2"], [/^([\d,.]+) Mo$/, "$1 MB"], [/^([\d,.]+) Ko$/, "$1 KB"],
  [/^(\d+) actions nécessitent votre attention$/, "$1 tasks need your attention"], [/^(\d+) jours de retard$/, "$1 days overdue"],
  [/^([\d\s,.]+) € · mensuel$/, "€$1 · monthly"], [/^([\d,.]+) Go$/, "$1 GB"],
  [/^([+−-]?\d+) ce mois-ci$/, "$1 this month"], [/^([\d,.]+) % de conversion$/, "$1% conversion"],
  [/^(\d+) urgents · (\d+) standards$/, "$1 urgent · $2 standard"], [/^(\d+) abonnements actifs$/, "$1 active subscriptions"],
  [/^Prévision fin d’année : (.+)$/, "Year-end forecast: $1"],
  [/^Pilotez la section (.+) depuis votre espace propriétaire\.$/, "Manage the $1 section from your owner workspace."],
];

const MONTH_REPLACEMENTS: Array<[RegExp, string]> = [
  [/\bjanvier\b/gi, "January"], [/\bfévrier\b/gi, "February"], [/\bmars\b/gi, "March"], [/\bavril\b/gi, "April"],
  [/\bmai\b/gi, "May"], [/\bjuin\b/gi, "June"], [/\bjuillet\b/gi, "July"], [/\baoût\b/gi, "August"],
  [/\bseptembre\b/gi, "September"], [/\boctobre\b/gi, "October"], [/\bnovembre\b/gi, "November"], [/\bdécembre\b/gi, "December"],
  [/sept\./gi, "Sep."],
];

const originalText = new WeakMap<Node, string>();
const renderedText = new WeakMap<Node, string>();
const originalAttrs = new WeakMap<Element, Map<string, string>>();
const renderedAttrs = new WeakMap<Element, Map<string, string>>();
const TRANSLATABLE_ATTRIBUTES = ["placeholder", "aria-label", "title", "alt"];

function translateValue(value: string, language: Language): string {
  if (language === "fr" || !value.trim()) return value;
  const leading = value.match(/^\s*/)?.[0] ?? "";
  const trailing = value.match(/\s*$/)?.[0] ?? "";
  const body = value.trim();
  let translated = TRANSLATIONS[body] ?? body;
  if (translated === body) {
    for (const [pattern, replacement] of DYNAMIC_RULES) {
      if (pattern.test(body)) { translated = body.replace(pattern, replacement); break; }
    }
  }
  if (translated === body) {
    for (const [pattern, replacement] of MONTH_REPLACEMENTS) translated = translated.replace(pattern, replacement);
  }
  return `${leading}${translated}${trailing}`;
}

function shouldSkip(node: Node): boolean {
  const parent = node.nodeType === Node.ELEMENT_NODE ? node as Element : node.parentElement;
  if (!parent || ["SCRIPT", "STYLE", "NOSCRIPT", "CODE"].includes(parent.tagName)) return true;
  return Boolean(parent.closest("[data-no-translate]"));
}

function applyText(node: Node, language: Language) {
  if (shouldSkip(node)) return;
  const current = node.nodeValue ?? "";
  const previousRendered = renderedText.get(node);
  if (!originalText.has(node) || (previousRendered !== undefined && current !== previousRendered)) originalText.set(node, current);
  const source = originalText.get(node) ?? current;
  let target = translateValue(source, language);
  if (language === "en" && node.parentElement?.closest(".weekdays") && source.trim() === "Mar") {
    target = source.replace("Mar", "Tue");
  }
  renderedText.set(node, target);
  if (current !== target) {
    const option = node.parentElement instanceof HTMLOptionElement ? node.parentElement : null;
    if (option && !option.hasAttribute("value") && source.trim()) option.setAttribute("value", source.trim());
    node.nodeValue = target;
  }
}

function applyAttribute(element: Element, attribute: string, language: Language) {
  if (element.closest("[data-no-translate]")) return;
  const current = element.getAttribute(attribute);
  if (current === null) return;
  const originals = originalAttrs.get(element) ?? new Map<string, string>();
  const rendered = renderedAttrs.get(element) ?? new Map<string, string>();
  if (!originals.has(attribute) || (rendered.has(attribute) && current !== rendered.get(attribute))) originals.set(attribute, current);
  const target = translateValue(originals.get(attribute) ?? current, language);
  rendered.set(attribute, target); originalAttrs.set(element, originals); renderedAttrs.set(element, rendered);
  if (current !== target) element.setAttribute(attribute, target);
}

function translateTree(root: Node, language: Language) {
  if (root.nodeType === Node.TEXT_NODE) applyText(root, language);
  if (root.nodeType === Node.ELEMENT_NODE) TRANSLATABLE_ATTRIBUTES.forEach((attribute) => applyAttribute(root as Element, attribute, language));
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT);
  let node = walker.nextNode();
  while (node) {
    if (node.nodeType === Node.TEXT_NODE) applyText(node, language);
    else TRANSLATABLE_ATTRIBUTES.forEach((attribute) => applyAttribute(node as Element, attribute, language));
    node = walker.nextNode();
  }
}

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguageState] = useState<Language>("fr");
  useEffect(() => { const saved = localStorage.getItem("patrimo-language"); if (saved === "fr" || saved === "en") setLanguageState(saved); }, []);
  useEffect(() => {
    document.documentElement.lang = language;
    document.title = language === "en" ? "Nestelya — Your property portfolio, made simple" : "Nestelya — Votre patrimoine, simplement";
    document.querySelector('meta[name="description"]')?.setAttribute("content", language === "en" ? "The smart platform that automates property, rent, booking and maintenance management." : "La plateforme intelligente qui automatise la gestion de vos biens, loyers, réservations et interventions.");
    translateTree(document.body, language);
    const observer = new MutationObserver((mutations) => mutations.forEach((mutation) => {
      if (mutation.type === "characterData") applyText(mutation.target, language);
      if (mutation.type === "attributes" && mutation.target instanceof Element && mutation.attributeName) applyAttribute(mutation.target, mutation.attributeName, language);
      mutation.addedNodes.forEach((node) => translateTree(node, language));
    }));
    observer.observe(document.body, { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: TRANSLATABLE_ATTRIBUTES });
    return () => observer.disconnect();
  }, [language]);
  const value = useMemo<LanguageContextValue>(() => ({ language, setLanguage: (next) => { localStorage.setItem("patrimo-language", next); setLanguageState(next); } }), [language]);
  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>;
}

export function LanguageSwitcher({ compact = false }: { compact?: boolean }) {
  const { language, setLanguage } = useContext(LanguageContext);
  return <div className={compact ? "language-switcher compact" : "language-switcher"} data-no-translate role="group" aria-label={language === "fr" ? "Choisir la langue" : "Choose language"}>
    <button type="button" className={language === "fr" ? "active" : ""} aria-pressed={language === "fr"} onClick={() => setLanguage("fr")}>FR</button>
    <button type="button" className={language === "en" ? "active" : ""} aria-pressed={language === "en"} onClick={() => setLanguage("en")}>EN</button>
  </div>;
}
