# Nestelya

Nestelya est une plateforme bilingue de gestion immobilière destinée aux
propriétaires, gestionnaires de biens et locations saisonnières.

## Fonctionnalités principales

- tableau de bord propriétaire et espace super-administrateur ;
- gestion des biens, locataires, réservations, finances et documents ;
- suivi des interventions et de la maintenance ;
- automatisations WhatsApp et e-mail ;
- paiements Stripe et Kkiapay avec vérification côté serveur ;
- interface français / anglais ;
- affichage responsive pour ordinateur, tablette et mobile.

## Technologies

- React 19
- Next.js 16
- TypeScript
- Vinext / Vite
- Cloudflare Workers
- Drizzle ORM (support D1)

## Prérequis

- Node.js `>=22.13.0`
- npm

## Installation locale

```bash
npm ci
cp .env.example .env.local
npm run dev
```

Ajoutez ensuite vos propres valeurs dans `.env.local`. Ne publiez jamais ce
fichier sur GitHub.

## Variables d’environnement

| Variable | Utilisation |
|---|---|
| `KKIAPAY_PUBLIC_KEY` | Clé publique du widget Kkiapay |
| `KKIAPAY_PRIVATE_KEY` | Vérification Kkiapay côté serveur |
| `KKIAPAY_SECRET_KEY` | Vérification Kkiapay côté serveur |
| `KKIAPAY_SANDBOX` | `true` en test, `false` en production |
| `KKIAPAY_CALLBACK_URL` | URL HTTPS de retour après paiement |
| `STRIPE_SECRET_KEY` | Création et vérification des paiements Stripe |
| `STRIPE_WEBHOOK_SECRET` | Vérification des webhooks Stripe |

## Commandes

```bash
npm run dev                 # développement local
npm run build               # compilation de production
npm test                    # compilation et tests
npm run lint                # vérification du code
npm run validate:artifact   # validation de l’artefact de déploiement
```

## Publication sur GitHub

Créez un dépôt vide, puis exécutez depuis ce dossier :

```bash
git remote add origin https://github.com/VOTRE-COMPTE/nestelya.git
git branch -M main
git push -u origin main
```

Le fichier `.gitignore` exclut les dépendances, compilations, journaux et
fichiers `.env`. Configurez les clés privées directement dans les secrets de
votre plateforme d’hébergement.

## Structure du projet

```text
app/                 Interface Next.js et modules fonctionnels
app/admin/           Centre super-administrateur
public/              Logos et images immobilières
worker/              API Stripe, Kkiapay et Worker Cloudflare
db/                  Schéma et accès Drizzle/D1
scripts/             Scripts de compilation et validation
tests/               Tests du rendu
.openai/hosting.json Liaison avec le projet ChatGPT Sites existant
```

## Sécurité

- Ne commitez jamais une clé privée, un secret de webhook ou un fichier `.env`.
- Renouvelez toute clé qui a déjà été exposée dans une conversation ou un dépôt.
- Confirmez toujours un paiement côté serveur avant d’activer un service.
